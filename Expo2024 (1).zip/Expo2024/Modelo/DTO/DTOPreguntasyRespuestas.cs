﻿namespace Expo2024.Modelo.DTO
{
    internal class DTOPreguntasyRespuestas : dbContext
    {
        //Campos tabla de Preguntas
        private string user;
        private string pregunta1;
        private string pregunta2;
        private string pregunta3;

        
        public string Pregunta1 { get => pregunta1; set => pregunta1 = value; }
        public string Pregunta2 { get => pregunta2; set => pregunta2 = value; }
        public string Pregunta3 { get => pregunta3; set => pregunta3 = value; }
        public string User { get => user; set => user = value; }
    }
}
