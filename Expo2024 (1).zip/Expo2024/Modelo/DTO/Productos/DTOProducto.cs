﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Modelo.DTO.Productos
{
    internal class DTOProducto : dbContext
    {
        private int id_Producto;
        private string nombre;
        private decimal costo;
        private decimal precio;
        private DateTime fecha_Vencimiento;
        private int id_Categoria;
        private int id_Proveedor;

        public int Id_Producto { get => id_Producto; set => id_Producto = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public decimal Costo { get => costo; set => costo = value; }
        public decimal Precio { get => precio; set => precio = value; }
        public DateTime Fecha_Vencimiento { get => fecha_Vencimiento; set => fecha_Vencimiento = value; }
        public int Id_Categoria { get => id_Categoria; set => id_Categoria = value; }
        public int Id_Proveedor { get => id_Proveedor; set => id_Proveedor = value; }
    }
}
