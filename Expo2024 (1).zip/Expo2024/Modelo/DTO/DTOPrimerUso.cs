﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Modelo.DTO
{
    internal class DTOPrimerUso : dbContext
    {
        private int idCafetin;
        private string nameCafetin;
        private string correoCafetin;
        private string telefonoCafetin;
        private string direccion;
        private DateTime fechaCreacion;
        

        public int IdCafetin { get => idCafetin; set => idCafetin = value; }
        public string NameCafetin { get => nameCafetin; set => nameCafetin = value; }
        public string CorreoCafetin { get => correoCafetin; set => correoCafetin = value; }
        public string TelefonoCafetin { get => telefonoCafetin; set => telefonoCafetin = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public DateTime FechaCreacion { get => fechaCreacion; set => fechaCreacion = value; }
    }
}
