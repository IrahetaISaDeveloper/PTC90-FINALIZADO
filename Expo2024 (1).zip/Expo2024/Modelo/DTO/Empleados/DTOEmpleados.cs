﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Modelo.DTO.Empleados
{
    internal class DTOEmpleados : dbContext
    {
        //Campos de la tabla Empleados
        private int idEmpleado;
        private string nombre;
        private string apellido;
        private string direccion;
        private string telefono;
        private string documento;
        private DateTime fechaNacimiento;
        private string correo;
        

        // Campos de la tabla TipoEmpleado
        private int idTipoEmpleado;
        private string nombreTipoEmpleado;

        private int idTipoUsuario;
        private string nombreTipoUsuario;

        private int idEstado;
        private string nombreEstado;

        //Campos para la tabla usuarios
        private int idUsuario;
        private string usuario;
        private string contrasena;
        private string estado;
        private int userAttempts;
        private string pin;

        // Propiedades de los campos
        public int IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Documento { get => documento; set => documento = value; }
        public DateTime FechaNacimiento { get => fechaNacimiento; set => fechaNacimiento = value; }
        public int IdTipoEmpleado { get => idTipoEmpleado; set => idTipoEmpleado = value; }
        public string NombreTipoEmpleado { get => nombreTipoEmpleado; set => nombreTipoEmpleado = value; }
        public int IdTipoUsuario { get => idTipoUsuario; set => idTipoUsuario = value; }
        public string NombreTipoUsuario { get => nombreTipoUsuario; set => nombreTipoUsuario = value; }
        public int IdEstado { get => idEstado; set => idEstado = value; }
        public string NombreEstado { get => nombreEstado; set => nombreEstado = value; }
        public string Usuario { get => usuario; set => usuario = value; }
        public string Contrasena { get => contrasena; set => contrasena = value; }
        public string Estado { get => estado; set => estado = value; }
        public int UserAttempts { get => userAttempts; set => userAttempts = value; }
        public string Pin { get => pin; set => pin = value; }
        public string Correo { get => correo; set => correo = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }
    }
}
