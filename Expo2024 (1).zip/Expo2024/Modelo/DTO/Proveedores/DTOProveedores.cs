﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Modelo.DTO.Proveedores
{
    internal class DTOProveedores : dbContext
    {
        private int id_Proveedor;
        private string nombre;
        private string direccion;
        private string telefono;
        private string correo;
        private int id_Categoria;

        public int Id_Proveedor { get => id_Proveedor; set => id_Proveedor = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Correo { get => correo; set => correo = value; }
        public int Id_Categoria { get => id_Categoria; set => id_Categoria = value; }
    }
}
