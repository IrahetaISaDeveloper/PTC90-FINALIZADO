﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Modelo.DTO
{
    internal class DTOLogin : dbContext
    {
        private string usuario = string.Empty;
        private string contraseña = string.Empty;
        private string nombre = string.Empty;
        private string roleId;
        private string email;
        private string access = string.Empty;

        public string Usuario { get => usuario; set => usuario = value; }
        public string Contraseña { get => contraseña; set => contraseña = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string RoleId { get => roleId; set => roleId = value; }
        public string Email { get => email; set => email = value; }
        public string Access { get => access; set => access = value; }
    }
}
