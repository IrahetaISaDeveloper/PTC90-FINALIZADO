﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Modelo.DTO.Ventas
{
    internal class DTOVentas : dbContext
    {
        ////Campos de la tabla venta
        //private int id_Venta;
        //private DateTime fecha_Venta;
        //private decimal total_Venta;

        ////Campos de la tabla detallesVentas
        //private int id_Producto;
        //private string cantidad;
        //private string descripcion;
        //private int id_Empleado;

        //public int Id_Venta { get => id_Venta; set => id_Venta = value; }
        //public DateTime Fecha_Venta { get => fecha_Venta; set => fecha_Venta = value; }
        //public decimal Total_Venta { get => total_Venta; set => total_Venta = value; }
        //public int Id_Producto { get => id_Producto; set => id_Producto = value; }
        //public string Cantidad { get => cantidad; set => cantidad = value; }
        //public string Descripcion { get => descripcion; set => descripcion = value; }
        //public int Id_Empleado { get => id_Empleado; set => id_Empleado = value; }

        // DTO para la tabla "ventas"
        public class VentaDTO
        {
            public int IdVenta { get; set; }
            public DateTime FechaVenta { get; set; }
            public decimal TotalVenta { get; set; }
            public List<DetalleVentaDTO> Detalles { get; set; }
        }

        // DTO para la tabla "detallesVentas"
        public class DetalleVentaDTO
        {
            public int IdProducto { get; set; }
            public int Cantidad { get; set; }
            public string Descripcion { get; set; }
            public int IdVenta { get; set; }
            public int IdEmpleado { get; set; }
        }

    }
}
