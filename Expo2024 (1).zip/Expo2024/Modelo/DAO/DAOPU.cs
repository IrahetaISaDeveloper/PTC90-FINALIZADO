﻿using Expo2024.Modelo.DTO.Empleados;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Controlador.Helper;
using System.Data;

namespace Expo2024.Modelo.DAO
{
    internal class DAOPU : DTOEmpleados
    {
        readonly SqlCommand comand = new SqlCommand();

        public bool RegistrarNegocio()
        {
            ClasesComunes common = new ClasesComunes();

            using (SqlConnection connection = getConnection())
            {
                // Verificar si la conexión está abierta antes de abrirla
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open(); // Solo abrir si está cerrada
                }

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Insertar en la tabla 'usuarios' primero
                        string queryUsuario = @"
                    INSERT INTO usuarios (nombreUsuario, contrasena, idTipo_Usuario, pinCambiarContra) 
                    VALUES (@nombreUsuario, @contrasena, @idTipo_Usuario, @pinCambiarContra);
                    SELECT SCOPE_IDENTITY();"; // Obtener el ID generado para el usuario

                        SqlCommand cmdUsuario = new SqlCommand(queryUsuario, connection, transaction);
                        cmdUsuario.Parameters.AddWithValue("@nombreUsuario", Usuario);
                        cmdUsuario.Parameters.AddWithValue("@contrasena", common.ComputeSha256Hash(Usuario + "FU123")); // Contraseña inicial
                        cmdUsuario.Parameters.AddWithValue("@idTipo_Usuario", IdTipoUsuario);
                        cmdUsuario.Parameters.AddWithValue("@pinCambiarContra", "1234"); // Pin inicial

                        // Ejecutar el comando e intentar obtener el idUsuario generado
                        int idUsuarioGenerado = Convert.ToInt32(cmdUsuario.ExecuteScalar());

                        // Insertar en la tabla 'empleados', usando el idUsuario generado
                        string queryEmpleado = @"
                    INSERT INTO empleados (nombre, apellido, direccion, telefono, documento, 
                                           fecha_Nacimiento, idTipo_Empleado, id_Estado, correo, id_Usuarios) 
                    VALUES (@nombre, @apellido, @direccion, @telefono, @documento, 
                            @fecha_Nacimiento, @idTipo_Empleado, @id_Estado, @correo, @id_Usuario);";

                        SqlCommand cmdEmpleado = new SqlCommand(queryEmpleado, connection, transaction);
                        cmdEmpleado.Parameters.AddWithValue("@nombre", Nombre);
                        cmdEmpleado.Parameters.AddWithValue("@apellido", Apellido);
                        cmdEmpleado.Parameters.AddWithValue("@direccion", Direccion);
                        cmdEmpleado.Parameters.AddWithValue("@telefono", Telefono);
                        cmdEmpleado.Parameters.AddWithValue("@documento", Documento);
                        cmdEmpleado.Parameters.AddWithValue("@fecha_Nacimiento", FechaNacimiento);
                        cmdEmpleado.Parameters.AddWithValue("@idTipo_Empleado", IdTipoEmpleado);
                        cmdEmpleado.Parameters.AddWithValue("@id_Estado", IdEstado);
                        cmdEmpleado.Parameters.AddWithValue("@correo", Correo);
                        cmdEmpleado.Parameters.AddWithValue("@id_Usuario", idUsuarioGenerado); // Relacionar con el usuario

                        cmdEmpleado.ExecuteNonQuery();

                        transaction.Commit(); // Confirmar la transacción si todo va bien
                        return true;
                    }
                    catch (SqlException ex)
                    {
                        transaction.Rollback(); // Revertir la transacción si hay algún error
                        MessageBox.Show($"Excepcion SQL: {ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback(); // Revertir la transacción si hay algún error
                        MessageBox.Show($"Excepcion: {ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }
    }
}

