﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Modelo.DTO.Productos;

namespace Expo2024.Modelo.DAO.Productos
{
    internal class DAOProductos : DTOProducto
    {
        readonly SqlCommand comand = new SqlCommand();
        public DataSet ObtenerData()//Llenar DataGridView
        {
            try
            {
                comand.Connection = getConnection();
                string query = "SELECT * FROM vistaProductos";
                SqlCommand cmdSelect = new SqlCommand(query, comand.Connection);
                cmdSelect.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmdSelect);
                DataSet ds = new DataSet();
                adp.Fill(ds, "vistaProductos");
                return ds;
            }
            catch (Exception)
            {
                MessageBox.Show($"Error al obtener los proveedor, verifique su conexión a internet o que el acceso al servidor o base de datos esten activos", "Error de ejecución", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            finally
            {
                comand.Connection.Close();//Cerrando Conexion
            }
        }
        public DataSet ObtenerProveedor() //conexion para llenar el combobox de proveedor
        {
            try
            {
                comand.Connection = getConnection();
                string query = "SELECT id_Proveedor,nombre FROM proveedor";
                SqlCommand cmdSelect = new SqlCommand(query, comand.Connection);
                DataSet ds = new DataSet();
                cmdSelect.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmdSelect);
                adp.Fill(ds, "proveedor");
                return ds;
            }
            catch (Exception)
            {
                MessageBox.Show("EC-010, No se pudieron encontrar los datos de proveedor, vuelva a intentar y si el error persiste consulte con el administrador", "Error al optener datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        public DataSet ObtenerCategoriaProveedor() // conexion para llenar el combobox de categoria de provedor
        {
            try
            {
                comand.Connection = getConnection();
                string query = "select id_Categoria,nombre FROM categoria";
                SqlCommand cmdSelect = new SqlCommand(query, comand.Connection);
                DataSet ds = new DataSet();
                cmdSelect.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmdSelect);
                adp.Fill(ds, "categoria");
                return ds;
            }
            catch (Exception)
            {
                MessageBox.Show("EC-011, No se pudieron encontrar los datos de Autores, vuelva a intentar y si el error persiste consulte con el administrador", "Error al optener datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
        public int GuardarProducto() // conexion y verificacion de parametros para hacer la insercion de datos
        {
            try
            {
                comand.Connection = getConnection();
                string query = "Insert into productos VALUES (@param1, @param2, @param3, @param4, @param5, @param6)";
                SqlCommand cmdInsert = new SqlCommand(query, comand.Connection);
                cmdInsert.Parameters.AddWithValue("param1", Nombre);
                cmdInsert.Parameters.AddWithValue("param2", Costo);
                cmdInsert.Parameters.AddWithValue("param3", Precio);
                cmdInsert.Parameters.AddWithValue("param4", Fecha_Vencimiento);
                cmdInsert.Parameters.AddWithValue("param5", Id_Categoria);
                cmdInsert.Parameters.AddWithValue("param6", Id_Proveedor);
                int valor = cmdInsert.ExecuteNonQuery();
                return valor;
            }
            catch (Exception)
            {

                return -1;
            }
        }
        public int EliminarProducto() // conexion para hacer la elimancion de datos
        {
            try
            {
                comand.Connection = getConnection();
                string query = "DELETE FROM productos WHERE id_Producto = @param1";
                SqlCommand cmd = new SqlCommand(query, comand.Connection);
                cmd.Parameters.AddWithValue("param1", Id_Producto);
                int respuesta = cmd.ExecuteNonQuery();
                respuesta = 1;
                return respuesta;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el producto: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }

            finally
            {
                getConnection().Close();
            }
        }

        public int Actualizar() //conexion y parametros para hacer la actualizacion de datos
        {
            try
            {
                comand.Connection = getConnection();
                string query = "UPDATE productos SET " +
                               "Nombre = @param1, " +
                               "Costo = @param2, " +
                               "Precio = @param3, " +
                               "Fecha_Vencimiento = @param4, " +
                               "Id_Categoria = @param5, " +
                               "Id_Proveedor = @param6 " +
                               "WHERE Id_Producto = @param7";

                SqlCommand cmd = new SqlCommand(query, comand.Connection);
                cmd.Parameters.AddWithValue("param1", Nombre);
                cmd.Parameters.AddWithValue("param2", Costo);
                cmd.Parameters.AddWithValue("param3", Precio);
                cmd.Parameters.AddWithValue("param4", Fecha_Vencimiento);
                cmd.Parameters.AddWithValue("param5", Id_Categoria);
                cmd.Parameters.AddWithValue("param6", Id_Proveedor);
                cmd.Parameters.AddWithValue("param7", Id_Producto);
                int respuesta = cmd.ExecuteNonQuery();

                return respuesta;
            }
            catch (Exception)
            {
                return -1;
            }
        }
        public DataSet Buscar(string valor)
        {

            try
            {
                comand.Connection = getConnection();
                string query = $@"
						SELECT * 
						FROM productos
						WHERE 
						nombre LIKE '%{valor}%' 
						OR costo LIKE '%{valor}%' 
						OR precio LIKE '%{valor}%' 
						OR fecha_Vencimiento LIKE '%{valor}%'
						OR CAST(id_Categoria AS VARCHAR) LIKE '%{valor}%'
						OR CAST(id_Proveedor AS VARCHAR) LIKE '%{valor}%'";


                SqlCommand cmd = new SqlCommand(query, comand.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds, "productos");
                return ds;
            }
            catch (Exception)
            {
                return null;
            }
            finally { comand.Connection.Close(); }

        }
    }
}
