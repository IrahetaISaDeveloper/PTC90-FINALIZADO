﻿using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Modelo.DAO
{
    internal class DAOIntervencionAdministrador : DTOLogin
    {


        // Verificar credenciales del administrador
        public bool VerificarContraAdministrador(string nombreUsuario)
        {
            try
            {
                using (SqlConnection connection = getConnection())
                {
                    // Asegúrate de abrir la conexión
                                       // Ajustamos la consulta para verificar por nombre de usuario y tipo de usuario (administrador)
                    string query = "SELECT * FROM usuarios WHERE nombreUsuario = @nombreUsuario AND idTipo_Usuario = 1";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@nombreUsuario", nombreUsuario); // Verificar por nombre de usuario

                        SqlDataReader reader = cmd.ExecuteReader();
                        return reader.HasRows; // Si hay filas, es un administrador válido
                    }
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Error de SQL: " + sqlex.Message);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error general: " + ex.Message);
                return false;
            }
        }

        // Cambiar la contraseña del usuario objetivo
        public bool CambiarContraUsuario()
        {
            try
            {
                using (SqlConnection connection = getConnection())
                {
                    
                    string query = "UPDATE usuarios SET contrasena = @contra WHERE nombreUsuario = @usuario";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("usuario", Usuario);
                        cmd.Parameters.AddWithValue("contra", Password);

                        int lineasAfectadas = cmd.ExecuteNonQuery();
                        return lineasAfectadas > 0;
                    }
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Error de SQL: " + sqlex.Message);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error general: " + ex.Message);
                return false;
            }
        }
    }
}
