﻿using Expo2024.Modelo.DTO.Proveedores;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Modelo.DAO.Proveedores
{
    internal class DAOProveedores : DTOProveedores
    {
        SqlCommand command = new SqlCommand();
        public DataSet obtenerProveedores()//Llenar DataGridView
        {
            try
            {
                command.Connection = getConnection();
                string query = "SELECT * FROM ViewProvider";
                SqlCommand cmdSelect = new SqlCommand(query, command.Connection);
                cmdSelect.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmdSelect);
                DataSet ds = new DataSet();
                adp.Fill(ds, "ViewProvider");
                return ds;
            }
            catch (Exception)
            {
                MessageBox.Show($"Error al obtener los proveedor, verifique su conexión a internet o que el acceso al servidor o base de datos esten activos", "Error de ejecución", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            finally
            {
                command.Connection.Close();//Cerrando Conexion
            }
        }

        public DataSet ObtenerCategoria()
        {

            try
            {
                command.Connection = getConnection();
                string query = "SELECT * FROM categoria";
                SqlCommand cmdSelect = new SqlCommand(query, command.Connection);
                cmdSelect.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmdSelect);
                DataSet ds = new DataSet();
                adp.Fill(ds, "categoria");
                return ds;

            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                command.Connection.Close();
            }
        }

        public int registarProveedor()
        {
            try
            {
                command.Connection = getConnection();
                string query = "Insert into proveedor VALUES (@param1, @param2, @param3, @param4, @param5)";
                SqlCommand cmdInsert = new SqlCommand(query, command.Connection);
                cmdInsert.Parameters.AddWithValue("param1", Nombre);
                cmdInsert.Parameters.AddWithValue("param2", Direccion);
                cmdInsert.Parameters.AddWithValue("param3", Telefono);
                cmdInsert.Parameters.AddWithValue("param4", Correo);
                cmdInsert.Parameters.AddWithValue("param5", Id_Categoria);
                int valor = cmdInsert.ExecuteNonQuery();
                return valor;
            }
            catch (Exception)
            {
                return -1;
            }
        }

        public int EliminarProv()
        {
            try
            {
                command.Connection = getConnection();
                string queryDelete = "DELETE proveedor WHERE id_Proveedor = @param1";
                SqlCommand cmdDelete = new SqlCommand(queryDelete, command.Connection);
                cmdDelete.Parameters.AddWithValue("param1", Id_Proveedor);
                int respuesta = cmdDelete.ExecuteNonQuery();
                respuesta = 1;
                return respuesta;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message} No se pudo eliminar El proveedor, verifique su conexión a internet o que los servicios esten activos", "Error de Delete", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                command.Connection.Close();
            }
        }


        public int ActualizarProve()
        {
            try
            {
                command.Connection = getConnection();

                string queryUpdate = "UPDATE proveedor SET nombre = @param1, direccion = @param2, telefono = @param3, correo = @param4, id_Categoria = @param5 WHERE id_Proveedor = @param6";



                SqlCommand cmdUpdate = new SqlCommand(queryUpdate, command.Connection);

                cmdUpdate.Parameters.AddWithValue("param1", Nombre);
                cmdUpdate.Parameters.AddWithValue("param2", Direccion);
                cmdUpdate.Parameters.AddWithValue("param3", Telefono);
                cmdUpdate.Parameters.AddWithValue("param4", Correo);
                cmdUpdate.Parameters.AddWithValue("param5", Id_Categoria);
                cmdUpdate.Parameters.AddWithValue("param6", Id_Proveedor);

                return cmdUpdate.ExecuteNonQuery();
            }
            catch (Exception)
            {

                return -1;

            }
            finally
            {

                command.Connection.Close();
            }
        }

        public DataSet buscarPersonas(string valor)
        {

            try
            {
                command.Connection = getConnection();
                string query = $@"
						SELECT * 
						FROM proveedor 
						WHERE 
						nombre LIKE '%{valor}%' 
						OR direccion LIKE '%{valor}%' 
						OR telefono LIKE '%{valor}%' 
						OR correo LIKE '%{valor}%'
						OR CAST(id_Proveedor AS VARCHAR) LIKE '%{valor}%'
						OR CAST(id_Categoria AS VARCHAR) LIKE '%{valor}%'";


                SqlCommand cmd = new SqlCommand(query, command.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds, "proveedor");
                return ds;
            }
            catch (Exception)
            {
                return null;
            }
            finally { command.Connection.Close(); }
        }
    }
}
