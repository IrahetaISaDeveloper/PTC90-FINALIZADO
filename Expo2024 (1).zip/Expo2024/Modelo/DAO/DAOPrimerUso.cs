﻿using Expo2024.Modelo.DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Modelo.DAO
{
    internal class DAOPrimerUso : DTOPrimerUso
    {
        readonly SqlCommand command = new SqlCommand();
        public bool RegistrarNegocio()
        {
            try
            {
                command.Connection = getConnection();
                string query = "INSERT INTO infoCafetin VALUES (@param1, @param2, @param3, @param4, @param5)";
                SqlCommand cmd = new SqlCommand(query, command.Connection);
                cmd.Parameters.AddWithValue("param1", NameCafetin);
                cmd.Parameters.AddWithValue("param2", CorreoCafetin);
                cmd.Parameters.AddWithValue("param3", TelefonoCafetin);
                cmd.Parameters.AddWithValue("param4", FechaCreacion);
                cmd.Parameters.AddWithValue("param5", Direccion);                
                int retorno = cmd.ExecuteNonQuery();
                return retorno > 0;
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Excepcion SQL: {ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Excepcion SQL: {ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                command.Connection.Close();
            }
        }

        /// <summary>
        /// El metodo se ejecuta al iniciar el programa
        /// </summary>
        /// <returns></returns>
        public int VerificarRegistroCafetin()
        {
            try
            {
                command.Connection = getConnection();
                string query = "SELECT COUNT(*) FROM infoCafetin";
                SqlCommand cmd = new SqlCommand(query, command.Connection);
                int totalEmpresa = (int)cmd.ExecuteScalar();
                return totalEmpresa;
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return -1;
            }
            finally
            {
                command.Connection.Close();
            }
        }
    }
}
