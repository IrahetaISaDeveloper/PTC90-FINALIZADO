﻿using Expo2024.Modelo.DTO.Empleados;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Expo2024.Controlador.Helper;


namespace Expo2024.Modelo.DAO.Empleados
{
    internal class DAOEmpleados : DTOEmpleados
    {
        readonly SqlCommand Command = new SqlCommand();

        // Método para obtener los tipos de empleado
        public DataSet ObtenerTiposEmpleado()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM tipoEmpleado";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet dt = new DataSet();
                adp.Fill(dt, "tipoEmpleado");

                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los tipos de empleado: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }

        public DataSet ObtenerEstados()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM estados";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet dt = new DataSet();
                adp.Fill(dt, "estados");

                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los estados: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }

        public DataSet ObtenerTipoUsuario()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM tipoUsuario";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet dt = new DataSet();
                adp.Fill(dt, "tipoUsuario");

                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los tipos de empleado: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }

        // Método para obtener los empleados
        public DataTable ObtenerEmpleados()
        {
            try
            {
                Command.Connection = getConnection();

                string query = @"SELECT
                e.id_Empleado,
                e.nombre,
                e.apellido,
                e.direccion,
                e.telefono,
                e.documento,
                e.fecha_Nacimiento,
                te.nombreTipo_Empleado,
                tu.idTipo_Usuario,
                s.id_Estado
            FROM
                empleados e
            INNER JOIN tipoUsuario tu ON e.idTipo_Usuario = tu.idTipo_Usuario
            INNER JOIN TipoEmpleado te ON e.nombreTipo_Empleado = te.nombreTipo_Empleado
            INNER JOIN estados s ON e.id_Estado = s.id_Estado;";


                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.ExecuteNonQuery();

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los datos: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }

        // Método para registrar un empleado
        public bool RegistrarUsuario()
        {
            ClasesComunes common = new ClasesComunes();

            using (SqlConnection connection = getConnection())
            {
                // Verificar si la conexión está abierta antes de abrirla
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open(); // Solo abrir si está cerrada
                }

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Insertar en la tabla 'usuarios' primero
                        string queryUsuario = @"
                    INSERT INTO usuarios (nombreUsuario, contrasena, idTipo_Usuario, pinCambiarContra) 
                    VALUES (@nombreUsuario, @contrasena, @idTipo_Usuario, @pinCambiarContra);
                    SELECT SCOPE_IDENTITY();"; // Obtener el ID generado para el usuario

                        SqlCommand cmdUsuario = new SqlCommand(queryUsuario, connection, transaction);
                        cmdUsuario.Parameters.AddWithValue("@nombreUsuario", Usuario);
                        cmdUsuario.Parameters.AddWithValue("@contrasena", common.ComputeSha256Hash(Usuario + "FU123")); // Contraseña inicial
                        cmdUsuario.Parameters.AddWithValue("@idTipo_Usuario", IdTipoUsuario);
                        cmdUsuario.Parameters.AddWithValue("@pinCambiarContra", "1234"); // Pin inicial

                        // Ejecutar el comando e intentar obtener el idUsuario generado
                        int idUsuarioGenerado = Convert.ToInt32(cmdUsuario.ExecuteScalar());

                        // Insertar en la tabla 'empleados', usando el idUsuario generado
                        string queryEmpleado = @"
                        INSERT INTO empleados (nombre, apellido, direccion, telefono, documento, 
                                               fecha_Nacimiento, idTipo_Empleado, id_Estado, correo, id_Usuarios) 
                        VALUES (@nombre, @apellido, @direccion, @telefono, @documento, 
                                @fecha_Nacimiento, @idTipo_Empleado, @id_Estado, @correo, @id_Usuario);";

                        SqlCommand cmdEmpleado = new SqlCommand(queryEmpleado, connection, transaction);
                        cmdEmpleado.Parameters.AddWithValue("@nombre", Nombre);
                        cmdEmpleado.Parameters.AddWithValue("@apellido", Apellido);
                        cmdEmpleado.Parameters.AddWithValue("@direccion", Direccion);
                        cmdEmpleado.Parameters.AddWithValue("@telefono", Telefono);
                        cmdEmpleado.Parameters.AddWithValue("@documento", Documento);
                        cmdEmpleado.Parameters.AddWithValue("@fecha_Nacimiento", FechaNacimiento);
                        cmdEmpleado.Parameters.AddWithValue("@idTipo_Empleado", IdTipoEmpleado);
                        cmdEmpleado.Parameters.AddWithValue("@id_Estado", IdEstado);
                        cmdEmpleado.Parameters.AddWithValue("@correo", Correo);
                        cmdEmpleado.Parameters.AddWithValue("@id_Usuario", idUsuarioGenerado); // Relacionar con el usuario

                        cmdEmpleado.ExecuteNonQuery();

                        transaction.Commit(); // Confirmar la transacción si todo va bien
                        return true;
                    }
                    catch (SqlException ex)
                    {
                        transaction.Rollback(); // Revertir la transacción si hay algún error
                        MessageBox.Show($"Excepcion SQL: {ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback(); // Revertir la transacción si hay algún error
                        MessageBox.Show($"Excepcion: {ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }

        // Método para actualizar un empleado

        public int ActualizarEmpleado()
        {
            SqlConnection connection = null;
            SqlTransaction transaction = null;

            try
            {
                connection = getConnection();

                if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }

                transaction = connection.BeginTransaction();

                // Actualización en la tabla empleados
                string queryEmpleados = "UPDATE empleados SET nombre = @nombre, apellido = @apellido, direccion = @direccion, telefono = @telefono, documento = @documento, fecha_Nacimiento = @fecha_Nacimiento, idTipo_Empleado = @idTipo_Empleado, id_Estado = @id_Estado, idTipo_Usuario = @idTipo_Usuario WHERE id_Empleado = @id_Empleado";

                SqlCommand cmdEmpleados = new SqlCommand(queryEmpleados, connection, transaction);
                cmdEmpleados.Parameters.AddWithValue("@id_Empleado", IdEmpleado);
                cmdEmpleados.Parameters.AddWithValue("@nombre", Nombre);
                cmdEmpleados.Parameters.AddWithValue("@apellido", Apellido);
                cmdEmpleados.Parameters.AddWithValue("@direccion", Direccion);
                cmdEmpleados.Parameters.AddWithValue("@telefono", Telefono);
                cmdEmpleados.Parameters.AddWithValue("@documento", Documento);
                cmdEmpleados.Parameters.AddWithValue("@fecha_Nacimiento", FechaNacimiento);
                cmdEmpleados.Parameters.AddWithValue("@idTipo_Empleado", IdTipoEmpleado);
                cmdEmpleados.Parameters.AddWithValue("@id_Estado", IdEstado);
                cmdEmpleados.Parameters.AddWithValue("@idTipo_Usuario", IdTipoUsuario);

                cmdEmpleados.ExecuteNonQuery();

                
                // Actualización en la tabla usuarios
                string queryUsuarios = "UPDATE usuarios SET nombreUsuario = @usuario WHERE id_Usuarios = @id_Usuario";

                SqlCommand cmdUsuarios = new SqlCommand(queryUsuarios, connection, transaction);
                cmdUsuarios.Parameters.AddWithValue("@id_Usuario", IdUsuario); // Asignar id de usuario
                cmdUsuarios.Parameters.AddWithValue("@usuario", Usuario); // Verificar que el valor de Usuario no sea nulo

                cmdUsuarios.ExecuteNonQuery();


                // Si ambas actualizaciones son exitosas, se confirma la transacción
                transaction.Commit();
                return 1;
            }
            catch (Exception ex)
            {
                // Si ocurre algún error, se revierte la transacción
                if (transaction != null)
                {
                    transaction.Rollback();
                }
                MessageBox.Show("Error al actualizar el empleado: " + ex.Message);
                return -1;
            }
            finally
            {
                if (connection != null && connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }



        //public int ActualizarEmpleado()
        //{
        //    try
        //    {
        //        Command.Connection = getConnection();

        //        string query = "UPDATE empleados SET nombre = @nombre, apellido = @apellido, direccion = @direccion, telefono = @telefono, documento = @documento, fecha_Nacimiento = @fecha_Nacimiento, idTipo_Empleado = @idTipo_Empleado, correo = @correo, id_Estado = @id_Estado, idTipo_Usuario = @idTipo_Usuario WHERE id_Empleado = @id_Empleado";

        //        SqlCommand cmd = new SqlCommand(query, Command.Connection);
        //        cmd.Parameters.AddWithValue("@id_Empleado", IdEmpleado);
        //        cmd.Parameters.AddWithValue("@nombre", Nombre);
        //        cmd.Parameters.AddWithValue("@apellido", Apellido);
        //        cmd.Parameters.AddWithValue("@direccion", Direccion);
        //        cmd.Parameters.AddWithValue("@telefono", Telefono);
        //        cmd.Parameters.AddWithValue("@documento", Documento);
        //        cmd.Parameters.AddWithValue("@fecha_Nacimiento", FechaNacimiento);
        //        cmd.Parameters.AddWithValue("@idTipo_Empleado", IdTipoEmpleado);
        //        cmd.Parameters.AddWithValue("@idTipo_Usuario", IdTipoUsuario);
        //        cmd.Parameters.AddWithValue("@id_Estado", IdEstado);
        //        cmd.Parameters.AddWithValue("@correo", Correo);

        //        return cmd.ExecuteNonQuery();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error al actualizar el empleado: " + ex.Message);
        //        return -1;
        //    }
        //    finally
        //    {
        //        getConnection().Close();
        //    }
        //}


        // Método para eliminar un empleado
        public int EliminarEmpleado()
        {
            try
            {
                Command.Connection = getConnection();

                string query = "DELETE FROM empleados WHERE id_Empleado = @id_Empleado";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.Parameters.AddWithValue("@id_Empleado", IdEmpleado);

                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el empleado:");
                return -1;
            }
            finally
            {
                getConnection().Close();
            }
        }

        public int EliminarUsuario()
        {
            try
            {
                Command.Connection = getConnection();

                string query = "DELETE FROM usuarios WHERE id_Usuarios = @id_Usuarios";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.Parameters.AddWithValue("@id_Usuarios", IdUsuario);

                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el usuario: " + ex.Message);
                return -1;
            }
            finally
            {
                getConnection().Close();
            }
        }



        // Método para buscar empleados por palabra clave (nombre, apellido o documento)
        public DataTable BuscarEmpleado(string valor)
        {
            try
            {
                Command.Connection = getConnection();

                string query = @"SELECT id_Empleado, Nombre, Apellido, FechaNacimiento, Documento, Direccion, 
                Telefono, correo, UsuarioID, Estado, TipoEmpleado, 
                Usuario, Rol
                FROM vista_empleados_usuariosDef
                WHERE Nombre LIKE @valor
                OR Apellido LIKE @valor
                OR Documento LIKE @valor
                OR Direccion LIKE @valor
                OR Telefono LIKE @valor
                OR FechaNacimiento LIKE @valor
                OR TipoEmpleado LIKE @valor
                OR Usuario LIKE @valor
                OR Rol LIKE @valor
                OR correo LIKE @valor";


                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.Parameters.AddWithValue("@valor", "%" + valor + "%");

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar el empleado: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }

        public bool VerificarPINSeguridad()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM usuarios WHERE usuario = @usuario AND pinCambiarContra = @pin AND estado = @estado";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.Parameters.AddWithValue("usuario", Usuario);
                cmd.Parameters.AddWithValue("pin", Pin);
                cmd.Parameters.AddWithValue("estado", true);
                SqlDataReader rd = cmd.ExecuteReader();
                return rd.HasRows;
            }
            catch (SqlException)
            {
                MessageBox.Show("No se pudo almacenar el PIN, vuelva a intentarlo. EC-005");
                return false;
            }
        }


        public bool RegistrarPIN()
        {
            try
            {
                Command.Connection = getConnection();
                string queryupdate = "UPDATE usuarios SET pinCambiarContra = @param1 WHERE usuario = @usuario";
                SqlCommand cmdupdate = new SqlCommand(queryupdate, Command.Connection);
                cmdupdate.Parameters.AddWithValue("param1", Pin);
                cmdupdate.Parameters.AddWithValue("usuario", Usuario);
                return cmdupdate.ExecuteNonQuery() > 0 ? true : false;
            }
            catch (SqlException)
            {
                return false;
            }
        }

        public bool RestablecerContrasena()
        {
            try
            {
                // Abrir conexión
                Command.Connection = getConnection();

                // Consulta para actualizar la contraseña del usuario
                string queryupdate = "UPDATE usuarios SET contrasena = @contrasena WHERE nombreUsuario = @usuario";
                SqlCommand cmdupdate = new SqlCommand(queryupdate, Command.Connection);

                // Asignar parámetros a la consulta
                cmdupdate.Parameters.AddWithValue("@contrasena", Contrasena);  // Contraseña ya encriptada
                cmdupdate.Parameters.AddWithValue("@usuario", Usuario);  // Nombre de usuario

                // Ejecutar la consulta y verificar si se afectaron filas
                return cmdupdate.ExecuteNonQuery() > 0;
            }
            catch (SqlException ex)
            {
                // Manejar la excepción SQL
                MessageBox.Show("Error al actualizar la contraseña: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            catch (Exception ex)
            {
                // Manejar cualquier otra excepción
                MessageBox.Show("Ocurrió un error inesperado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                // Asegurarse de cerrar la conexión
                if (Command.Connection != null && Command.Connection.State == System.Data.ConnectionState.Open)
                {
                    Command.Connection.Close();
                }
            }
        }
        public DataSet ObtenerData()//Llenar DataGridView
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM vista_empleados_usuariosDef";
                SqlCommand cmdSelect = new SqlCommand(query, Command.Connection);
                cmdSelect.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmdSelect);
                DataSet ds = new DataSet();
                adp.Fill(ds, "vista_empleados_usuariosDef");
                return ds;
            }
            catch (Exception)
            {
                MessageBox.Show($"Error al obtener los proveedor, verifique su conexión a internet o que el acceso al servidor o base de datos esten activos", "Error de ejecución", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            finally
            {
                Command.Connection.Close();//Cerrando Conexion
            }
        }
    }
}
