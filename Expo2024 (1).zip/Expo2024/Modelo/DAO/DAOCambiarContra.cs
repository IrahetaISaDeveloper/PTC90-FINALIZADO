﻿using Expo2024.Modelo.DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Modelo.DAO
{
    internal class DAOCambiarContra : DTOLogin
    {
        SqlCommand SqlCommand = new SqlCommand();

        public string ComprobarUsuario(string correo)
        {
            SqlCommand.Connection = getConnection();
            string query = @"
                SELECT u.nombreUsuario 
                FROM empleados e
                INNER JOIN usuarios u ON e.id_Usuarios = u.id_Usuarios
                WHERE e.correo = @correo";

            SqlCommand cmd = new SqlCommand(query, SqlCommand.Connection);
            cmd.Parameters.AddWithValue("@correo", correo);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                return reader["nombreUsuario"].ToString(); // Retorna el nombre del usuario
            }
            else
            {
                return null; // Retorna null si no encuentra un resultado
            }
        }

        public bool DAOCambiarclave()
        {
            try
            {
                using (SqlConnection connection = getConnection()) // Asegúrate de cerrar la conexión correctamente.
                { // Abre la conexión
                    string query = "UPDATE usuarios SET contrasena = @contra WHERE nombreUsuario = @usuario";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@usuario", User);  // Asegúrate de que 'User' tiene un valor válido
                        cmd.Parameters.AddWithValue("@contra", Password); // Usa 'Password' o 'Contraseña', pero mantén consistencia

                        int lineasAfectadas = cmd.ExecuteNonQuery();

                        if (lineasAfectadas > 0)
                        {
                            // Si se afectaron filas, la contraseña se cambió exitosamente
                            return true;
                        }
                        else
                        {
                            // Si no se afectaron filas, el usuario no se encontró o algo falló
                            MessageBox.Show("No se pudo actualizar la contraseña. Verifica que el usuario exista.");
                            return false;
                        }
                    }
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Error de SQL: " + sqlex.Message);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error general: " + ex.Message);
                return false;
            }
        }

        public bool ComprobarusuarioPorAdmin()
        {
            SqlCommand.Connection = getConnection();
            string query = "SELECT * FROM  usuario WHERE nombreUsuario = @usuario AND estado = @estado";
            SqlCommand cmd = new SqlCommand(query, SqlCommand.Connection);
            cmd.Parameters.AddWithValue("usuario", User);
            cmd.Parameters.AddWithValue("estado", true);
            SqlDataReader reader = cmd.ExecuteReader();
            return reader.HasRows;
        }


        //public bool DAOCambiarclave()
        //{
        //    try
        //    {
        //        SqlCommand.Connection = getConnection();
        //        string query = "UPDATE usuarios SET contrasena = @contra WHERE  nombreUsuario = @usuario";
        //        SqlCommand cmd = new SqlCommand(query, SqlCommand.Connection);
        //        cmd.Parameters.AddWithValue("usuario", User);
        //        cmd.Parameters.AddWithValue("contra", Contraseña);

        //        int lineasAfectadas = cmd.ExecuteNonQuery();
        //        cmd.Parameters.AddWithValue("estado", true);
        //        SqlDataReader reader = cmd.ExecuteReader();
        //        return reader.HasRows;




        //    }
        //    catch (SqlException sqlex)
        //    {
        //        MessageBox.Show(sqlex.Message);
        //        return false;


        //    }
        //    catch (Exception ex)
        //    {

        //        {
        //            MessageBox.Show(ex.Message);
        //            return false;


        //        }

        //    }
        //    finally
        //    {
        //        getConnection().Close();
        //    }
        //}
    }
}
