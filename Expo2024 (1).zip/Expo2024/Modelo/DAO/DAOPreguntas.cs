﻿using Expo2024.Modelo.DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Modelo;
using System.Data;

namespace Expo2024.Modelo.DAO
{
    internal class DAOPreguntas : DTOPreguntasyRespuestas
    {
        readonly SqlCommand Command = new SqlCommand();

        public int IngresarPreguntas()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "INSERT INTO preguntas (id_Usuarios, pregunta1, pregunta2, pregunta3) VALUES(@id_Usuario, @Pregunta1, @pregunta2, @pregunta3)";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.Parameters.AddWithValue("id_Usuario", User);
                cmd.Parameters.AddWithValue("Pregunta1", Pregunta1);
                cmd.Parameters.AddWithValue("pregunta2", Pregunta2);
                cmd.Parameters.AddWithValue("pregunta3", Pregunta3);
                int respuesta = cmd.ExecuteNonQuery();
                return respuesta;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("Algo ha salido mal, no se pudieron guardar las preguntas.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
        }

            public bool VerificarUsuarioYContra(string nombreUsuario, string contrasena)
            {
                try
                {
                    using (SqlConnection connection = getConnection())
                    {
                        if (connection == null || connection.State != ConnectionState.Open)
                        {
                            MessageBox.Show("No se pudo abrir la conexión a la base de datos.");
                            return false;
                        }

                        string query = "SELECT * FROM usuarios WHERE nombreUsuario = @nombreUsuario AND contrasena = @contra";
                        using (SqlCommand cmd = new SqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);
                            cmd.Parameters.AddWithValue("@contra", contrasena);

                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                return reader.HasRows;
                            }
                        }
                    }

                }
                catch (SqlException sqlex)
                {
                    MessageBox.Show("Error de SQL: " + sqlex.Message);
                    return false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error general: " + ex.Message);
                    return false;
                }
            }

        public bool VerificarRespuestas(string usuario, string respuesta1, string respuesta2, string respuesta3)
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM preguntas WHERE id_Usuarios = (SELECT id_Usuarios FROM usuarios WHERE nombreUsuario = @nombreUsuario) " +
                               "AND pregunta1 = @pregunta1 AND pregunta2 = @pregunta2 AND pregunta3 = @pregunta3";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.Parameters.AddWithValue("@nombreUsuario", usuario);
                cmd.Parameters.AddWithValue("@pregunta1", respuesta1);
                cmd.Parameters.AddWithValue("@pregunta2", respuesta2);
                cmd.Parameters.AddWithValue("@pregunta3", respuesta3);
                SqlDataReader reader = cmd.ExecuteReader();
                return reader.HasRows;  // Si hay filas, las respuestas son correctas
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error de SQL: " + ex.Message);
                return false;
            }
        }



        public bool ObtenerRespuestas()
        {
            try
            {
                Command.Connection = getConnection();
                string queryReader = "SELECT pregunta1, pregunta2, pregunta3 FROM preguntas WHERE Pregunta1 = @pregunta1 AND pregunta2 = @pregunta2 AND pregunta3 = @pregunta3 AND id_Usuarios = @id_Usuarios";
                SqlCommand cmd = new SqlCommand(queryReader, Command.Connection);
                cmd.Parameters.AddWithValue("pregunta1", Pregunta1);
                cmd.Parameters.AddWithValue("pregunta2", Pregunta2);
                cmd.Parameters.AddWithValue("pregunta3", Pregunta3);
                cmd.Parameters.AddWithValue("id_Usuarios", User);
                SqlDataReader reader = cmd.ExecuteReader();
                return reader.HasRows;

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"{ex.Message}");
                return false;

            }
        }
    }
}
