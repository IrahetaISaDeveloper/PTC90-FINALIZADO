﻿using Expo2024.Controlador.Productos;
using Expo2024.Modelo.DTO.Ventas;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Modelo.DAO.Ventas
{
    internal class DAOVentas : DTOVentas
    {
        readonly SqlCommand Command = new SqlCommand();
        public DataSet ObtenerVentas()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM ventas";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "ventas");

                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener las ventas: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }

        public DataSet ObtenerDetalles()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT * FROM detallesVentas";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "detallesVentas");

                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener las ventas: " + ex.Message);
                return null;
            }
            finally
            {
                getConnection().Close();
            }
        }



        public int InsertVenta(VentaDTO venta)
        {
            using (SqlConnection conn = getConnection())
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // Insertar en tabla "ventas"
                    SqlCommand cmd = new SqlCommand("INSERT INTO ventas (fecha_Venta, total_Venta) OUTPUT INSERTED.id_Venta VALUES (@fechaVenta, @totalVenta)", conn, transaction);
                    cmd.Parameters.AddWithValue("@fechaVenta", venta.FechaVenta);
                    cmd.Parameters.AddWithValue("@totalVenta", venta.TotalVenta);

                    int idVenta = (int)cmd.ExecuteScalar();

                    // Insertar en tabla "detallesVentas"
                    foreach (var detalle in venta.Detalles)
                    {
                        SqlCommand cmdDetalle = new SqlCommand("INSERT INTO detallesVentas (id_Producto, cantidad, descripcion, id_Venta, id_Empleado) VALUES (@idProducto, @cantidad, @descripcion, @idVenta, @idEmpleado)", conn, transaction);
                        cmdDetalle.Parameters.AddWithValue("@idProducto", detalle.IdProducto);
                        cmdDetalle.Parameters.AddWithValue("@cantidad", detalle.Cantidad);
                        cmdDetalle.Parameters.AddWithValue("@descripcion", detalle.Descripcion);
                        cmdDetalle.Parameters.AddWithValue("@idVenta", idVenta);
                        cmdDetalle.Parameters.AddWithValue("@idEmpleado", detalle.IdEmpleado);

                        cmdDetalle.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return idVenta;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public bool UpdateVenta(VentaDTO venta)
        {
            using (SqlConnection conn = getConnection())
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // Actualizar en tabla "ventas"
                    SqlCommand cmd = new SqlCommand("UPDATE ventas SET fecha_Venta = @fechaVenta, total_Venta = @totalVenta WHERE id_Venta = @idVenta", conn, transaction);
                    cmd.Parameters.AddWithValue("@fechaVenta", venta.FechaVenta);
                    cmd.Parameters.AddWithValue("@totalVenta", venta.TotalVenta);
                    cmd.Parameters.AddWithValue("@idVenta", venta.IdVenta);

                    cmd.ExecuteNonQuery();

                    // Borrar los detalles existentes
                    SqlCommand cmdDeleteDetalles = new SqlCommand("DELETE FROM detallesVentas WHERE id_Venta = @idVenta", conn, transaction);
                    cmdDeleteDetalles.Parameters.AddWithValue("@idVenta", venta.IdVenta);
                    cmdDeleteDetalles.ExecuteNonQuery();

                    // Insertar los nuevos detalles
                    foreach (var detalle in venta.Detalles)
                    {
                        SqlCommand cmdDetalle = new SqlCommand("INSERT INTO detallesVentas (id_Producto, cantidad, descripcion, id_Venta, id_Empleado) VALUES (@idProducto, @cantidad, @descripcion, @idVenta, @idEmpleado)", conn, transaction);
                        cmdDetalle.Parameters.AddWithValue("@idProducto", detalle.IdProducto);
                        cmdDetalle.Parameters.AddWithValue("@cantidad", detalle.Cantidad);
                        cmdDetalle.Parameters.AddWithValue("@descripcion", detalle.Descripcion);
                        cmdDetalle.Parameters.AddWithValue("@idVenta", venta.IdVenta);
                        cmdDetalle.Parameters.AddWithValue("@idEmpleado", detalle.IdEmpleado);

                        cmdDetalle.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public bool DeleteVenta(int idVenta)
        {
            using (SqlConnection conn = getConnection())
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // Borrar detalles
                    SqlCommand cmdDeleteDetalles = new SqlCommand("DELETE FROM detallesVentas WHERE id_Venta = @idVenta", conn, transaction);
                    cmdDeleteDetalles.Parameters.AddWithValue("@idVenta", idVenta);
                    cmdDeleteDetalles.ExecuteNonQuery();

                    // Borrar venta
                    SqlCommand cmdDeleteVenta = new SqlCommand("DELETE FROM ventas WHERE id_Venta = @idVenta", conn, transaction);
                    cmdDeleteVenta.Parameters.AddWithValue("@idVenta", idVenta);
                    cmdDeleteVenta.ExecuteNonQuery();

                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }
}
