﻿using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Modelo.DAO
{
    internal class DAOLogin : DTOLogin
    {
        SqlCommand Command = new SqlCommand();

        public bool Login(string username, string password)
        {
            try
            {
                // Create a parameterized query
                string query = "SELECT * FROM usuarios WHERE nombreUsuario = @Username AND contrasena = @Password";
                SqlCommand cmd = new SqlCommand(query, getConnection());

                // Add parameters
                cmd.Parameters.AddWithValue("Username", username);
                cmd.Parameters.AddWithValue("Password", password);

                // Execute the query
                SqlDataReader rd = cmd.ExecuteReader();

                // Check if the user exists
                return rd.HasRows;
            }
            catch (SqlException sqlex)
            {
                // Log the error
                Console.WriteLine(sqlex.Message);
                return false;
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                getConnection().Close();
            }
        }

        public int ValidarPrimerUsoSistema()
        {
            try
            {
                Command.Connection = getConnection();
                string query = "SELECT COUNT(*) FROM usuarios";
                SqlCommand cmd = new SqlCommand(query, Command.Connection);
                int totalUsuarios = (int)cmd.ExecuteScalar();
                return totalUsuarios;
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return -1;
            }
            finally
            {
                getConnection().Close();
            }
        }
    }
}




