﻿using Expo2024.Controlador;
using Expo2024.Vista.Ventas;
using Expo2024.Vista.Empleados;
using Expo2024.Vista.Productos;
using Expo2024.Vista.Proveedores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Vista;

namespace Expo2024
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new ViewAdminEmpleados());
            ControllerInnit.ValidarVista();
        }
    }
}
