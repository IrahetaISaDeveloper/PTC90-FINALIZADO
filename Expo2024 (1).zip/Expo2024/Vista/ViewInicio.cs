﻿using Expo2024.Controlador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista
{
    public partial class ViewInicio : Form
    {
        public ViewInicio()
        {
            InitializeComponent();
            ControllerInicio controllerInicio = new ControllerInicio(this);
        }
    }
}
