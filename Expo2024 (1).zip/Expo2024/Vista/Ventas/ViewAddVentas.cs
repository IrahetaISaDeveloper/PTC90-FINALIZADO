﻿using Expo2024.Controlador.Ventas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Expo2024.Controlador.Ventas.ControllerAddVentas;
using static Expo2024.Modelo.DTO.Ventas.DTOVentas;

namespace Expo2024.Vista.Ventas
{
    public partial class ViewAddVentas : Form
    {
        public ViewAddVentas()
        {
            InitializeComponent();
            ControllerAddVentas control = new ControllerAddVentas(this);
            
        }

        private VentaController ventaController = new VentaController();
        private List<DetalleVentaDTO> detallesVenta = new List<DetalleVentaDTO>();

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {    
            DetalleVentaDTO detalle = new DetalleVentaDTO
            {
                
                IdProducto = int.Parse(cmbProducto.SelectedValue.ToString()),
                Cantidad = int.Parse(txtCantidad.Text),
                Descripcion = txtDescripcion.Text,
                IdEmpleado = int.Parse(cmbVendedor.SelectedValue.ToString())
            };

            detallesVenta.Add(detalle);
            // Mostrar en un DataGridView u otro control para visualización
        }

        private void btnCrearVenta_Click(object sender, EventArgs e)
        {
            VentaDTO venta = new VentaDTO
            {
                FechaVenta = dtpFechaVenta.Value,
                TotalVenta = decimal.Parse(txtTotalVenta.Text),
                Detalles = detallesVenta
            };

            int idVenta = ventaController.CrearVenta(venta);
            MessageBox.Show("Venta creada con éxito, ID: " + idVenta);
        }
    }
}
