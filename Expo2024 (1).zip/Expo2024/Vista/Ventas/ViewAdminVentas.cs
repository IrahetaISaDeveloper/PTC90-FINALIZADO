﻿using Expo2024.Controlador.Ventas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista.Ventas
{
    public partial class ViewAdminVentas : Form
    {
        public ViewAdminVentas()
        {
            InitializeComponent();
            ControllerAdminVentas control = new ControllerAdminVentas(this);
        }

        private void ViewAdminVentas_Load(object sender, EventArgs e)
        {

        }


    }
}
