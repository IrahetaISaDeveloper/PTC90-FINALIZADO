﻿using Expo2024.Controlador.Empleados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeliciosOS.Vista.Empleados
{
    public partial class ViewActualizarEmpleado : Form
    {
        public ViewActualizarEmpleado()
        {
            InitializeComponent();
            ControllerAdminEmpleados controller = new ControllerAdminEmpleados(this);
        }

        private void cmbEstadoActualizar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ViewActualizarEmpleado_Load(object sender, EventArgs e)
        {

        }
    }
}
