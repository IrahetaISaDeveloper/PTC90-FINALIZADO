﻿using Expo2024.Controlador.Empleados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista.Empleados
{
    public partial class ViewAdminEmpleados : Form
    {
        public ViewAdminEmpleados()
        {
            InitializeComponent();
            ControllerAdminEmpleados empleados = new ControllerAdminEmpleados(this);
        }
    }
}
