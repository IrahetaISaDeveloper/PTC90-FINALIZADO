﻿using Expo2024.Controlador.Empleados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista.Empleados
{
    public partial class ViewAddEmpleado : Form
    {
        public ViewAddEmpleado(int accion)
        {
            InitializeComponent();
            ControllerAddEmpleados objAddEmpleado = new ControllerAddEmpleados(this, accion);
        }

        public ViewAddEmpleado(int accion, int idEmpleado, string nombre, string apellido, string direccion, string telefono, string documento, DateTime fechaNacimiento, string tipoEmpleado, int idUsuario, int idEstado)
        {
            InitializeComponent();
            ControllerAddEmpleados objAddEmpleado = new ControllerAddEmpleados(this, accion, idEmpleado, nombre, apellido, direccion, telefono, documento, fechaNacimiento, tipoEmpleado, idUsuario, idEstado);
        }

        private void ViewAddEmpleado_Load(object sender, EventArgs e)
        {

        }
    }
}
