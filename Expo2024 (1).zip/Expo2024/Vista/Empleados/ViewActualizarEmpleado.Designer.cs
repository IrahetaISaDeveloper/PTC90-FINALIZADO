﻿namespace DeliciosOS.Vista.Empleados
{
    partial class ViewActualizarEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.estado = new System.Windows.Forms.Label();
            this.cmbTipoEmpleadoActualizar = new System.Windows.Forms.ComboBox();
            this.cmbEstadoActualizar = new System.Windows.Forms.ComboBox();
            this.txtCorreoActualizar = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.GrpUser = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtUsuarioEmpActualizar = new System.Windows.Forms.TextBox();
            this.cmbTipoUsuarioActualizar = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDireccionActualizar = new System.Windows.Forms.TextBox();
            this.mskDocumentoActualizar = new System.Windows.Forms.MaskedTextBox();
            this.dtFechaNacActualizar = new System.Windows.Forms.DateTimePicker();
            this.txtTelefonoActualizar = new System.Windows.Forms.TextBox();
            this.txtApellidoActualizar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombreActualizar = new System.Windows.Forms.TextBox();
            this.LblNombre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtIdEmpleadoActualizar = new System.Windows.Forms.TextBox();
            this.txtIDusuario = new System.Windows.Forms.TextBox();
            this.GrpUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(32, 229);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 13);
            this.label11.TabIndex = 41;
            this.label11.Text = "Tipo Empleado";
            // 
            // estado
            // 
            this.estado.AutoSize = true;
            this.estado.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estado.ForeColor = System.Drawing.Color.Black;
            this.estado.Location = new System.Drawing.Point(167, 200);
            this.estado.Name = "estado";
            this.estado.Size = new System.Drawing.Size(42, 13);
            this.estado.TabIndex = 40;
            this.estado.Text = "Estado";
            // 
            // cmbTipoEmpleadoActualizar
            // 
            this.cmbTipoEmpleadoActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbTipoEmpleadoActualizar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoEmpleadoActualizar.FormattingEnabled = true;
            this.cmbTipoEmpleadoActualizar.Location = new System.Drawing.Point(33, 239);
            this.cmbTipoEmpleadoActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbTipoEmpleadoActualizar.Name = "cmbTipoEmpleadoActualizar";
            this.cmbTipoEmpleadoActualizar.Size = new System.Drawing.Size(122, 21);
            this.cmbTipoEmpleadoActualizar.TabIndex = 39;
            // 
            // cmbEstadoActualizar
            // 
            this.cmbEstadoActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbEstadoActualizar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstadoActualizar.FormattingEnabled = true;
            this.cmbEstadoActualizar.Location = new System.Drawing.Point(170, 210);
            this.cmbEstadoActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbEstadoActualizar.Name = "cmbEstadoActualizar";
            this.cmbEstadoActualizar.Size = new System.Drawing.Size(122, 21);
            this.cmbEstadoActualizar.TabIndex = 38;
            this.cmbEstadoActualizar.SelectedIndexChanged += new System.EventHandler(this.cmbEstadoActualizar_SelectedIndexChanged);
            // 
            // txtCorreoActualizar
            // 
            this.txtCorreoActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCorreoActualizar.Location = new System.Drawing.Point(33, 181);
            this.txtCorreoActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCorreoActualizar.Name = "txtCorreoActualizar";
            this.txtCorreoActualizar.Size = new System.Drawing.Size(277, 20);
            this.txtCorreoActualizar.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(34, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 36;
            this.label6.Text = "Correo";
            // 
            // btnActualizar
            // 
            this.btnActualizar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnActualizar.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizar.ForeColor = System.Drawing.Color.Black;
            this.btnActualizar.Location = new System.Drawing.Point(136, 327);
            this.btnActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(65, 20);
            this.btnActualizar.TabIndex = 34;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            // 
            // GrpUser
            // 
            this.GrpUser.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrpUser.Controls.Add(this.label10);
            this.GrpUser.Controls.Add(this.txtUsuarioEmpActualizar);
            this.GrpUser.Controls.Add(this.cmbTipoUsuarioActualizar);
            this.GrpUser.Controls.Add(this.label9);
            this.GrpUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GrpUser.Location = new System.Drawing.Point(32, 275);
            this.GrpUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GrpUser.Name = "GrpUser";
            this.GrpUser.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GrpUser.Size = new System.Drawing.Size(275, 43);
            this.GrpUser.TabIndex = 35;
            this.GrpUser.TabStop = false;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(148, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Rol";
            // 
            // txtUsuarioEmpActualizar
            // 
            this.txtUsuarioEmpActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUsuarioEmpActualizar.Location = new System.Drawing.Point(3, 18);
            this.txtUsuarioEmpActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUsuarioEmpActualizar.Name = "txtUsuarioEmpActualizar";
            this.txtUsuarioEmpActualizar.Size = new System.Drawing.Size(144, 20);
            this.txtUsuarioEmpActualizar.TabIndex = 14;
            // 
            // cmbTipoUsuarioActualizar
            // 
            this.cmbTipoUsuarioActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbTipoUsuarioActualizar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoUsuarioActualizar.FormattingEnabled = true;
            this.cmbTipoUsuarioActualizar.Location = new System.Drawing.Point(150, 18);
            this.cmbTipoUsuarioActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbTipoUsuarioActualizar.Name = "cmbTipoUsuarioActualizar";
            this.cmbTipoUsuarioActualizar.Size = new System.Drawing.Size(122, 21);
            this.cmbTipoUsuarioActualizar.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(4, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Usuario";
            // 
            // txtDireccionActualizar
            // 
            this.txtDireccionActualizar.Location = new System.Drawing.Point(35, 132);
            this.txtDireccionActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtDireccionActualizar.Multiline = true;
            this.txtDireccionActualizar.Name = "txtDireccionActualizar";
            this.txtDireccionActualizar.Size = new System.Drawing.Size(275, 36);
            this.txtDireccionActualizar.TabIndex = 32;
            // 
            // mskDocumentoActualizar
            // 
            this.mskDocumentoActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mskDocumentoActualizar.Location = new System.Drawing.Point(207, 106);
            this.mskDocumentoActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mskDocumentoActualizar.Mask = "00000000>L";
            this.mskDocumentoActualizar.Name = "mskDocumentoActualizar";
            this.mskDocumentoActualizar.Size = new System.Drawing.Size(103, 20);
            this.mskDocumentoActualizar.TabIndex = 31;
            // 
            // dtFechaNacActualizar
            // 
            this.dtFechaNacActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtFechaNacActualizar.CalendarTitleBackColor = System.Drawing.Color.DodgerBlue;
            this.dtFechaNacActualizar.CalendarTrailingForeColor = System.Drawing.Color.Green;
            this.dtFechaNacActualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFechaNacActualizar.Location = new System.Drawing.Point(36, 106);
            this.dtFechaNacActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtFechaNacActualizar.Name = "dtFechaNacActualizar";
            this.dtFechaNacActualizar.Size = new System.Drawing.Size(169, 22);
            this.dtFechaNacActualizar.TabIndex = 30;
            // 
            // txtTelefonoActualizar
            // 
            this.txtTelefonoActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTelefonoActualizar.Location = new System.Drawing.Point(33, 210);
            this.txtTelefonoActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTelefonoActualizar.Name = "txtTelefonoActualizar";
            this.txtTelefonoActualizar.Size = new System.Drawing.Size(120, 20);
            this.txtTelefonoActualizar.TabIndex = 33;
            // 
            // txtApellidoActualizar
            // 
            this.txtApellidoActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtApellidoActualizar.Location = new System.Drawing.Point(192, 72);
            this.txtApellidoActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtApellidoActualizar.Name = "txtApellidoActualizar";
            this.txtApellidoActualizar.Size = new System.Drawing.Size(118, 20);
            this.txtApellidoActualizar.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(207, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Documento";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(32, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "N° Teléfono";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(34, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Dirección";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(35, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Fecha nacimiento";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(190, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Apellidos";
            // 
            // txtNombreActualizar
            // 
            this.txtNombreActualizar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNombreActualizar.Location = new System.Drawing.Point(37, 72);
            this.txtNombreActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreActualizar.MaxLength = 60;
            this.txtNombreActualizar.Name = "txtNombreActualizar";
            this.txtNombreActualizar.Size = new System.Drawing.Size(118, 20);
            this.txtNombreActualizar.TabIndex = 22;
            // 
            // LblNombre
            // 
            this.LblNombre.AutoSize = true;
            this.LblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNombre.ForeColor = System.Drawing.Color.Black;
            this.LblNombre.Location = new System.Drawing.Point(63, 36);
            this.LblNombre.Name = "LblNombre";
            this.LblNombre.Size = new System.Drawing.Size(221, 25);
            this.LblNombre.TabIndex = 28;
            this.LblNombre.Text = "Actualizar Empleados";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(35, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Nombres";
            // 
            // txtIdEmpleadoActualizar
            // 
            this.txtIdEmpleadoActualizar.Enabled = false;
            this.txtIdEmpleadoActualizar.Location = new System.Drawing.Point(177, 240);
            this.txtIdEmpleadoActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIdEmpleadoActualizar.Name = "txtIdEmpleadoActualizar";
            this.txtIdEmpleadoActualizar.ReadOnly = true;
            this.txtIdEmpleadoActualizar.Size = new System.Drawing.Size(68, 20);
            this.txtIdEmpleadoActualizar.TabIndex = 42;
            // 
            // txtIDusuario
            // 
            this.txtIDusuario.Enabled = false;
            this.txtIDusuario.Location = new System.Drawing.Point(249, 240);
            this.txtIDusuario.Margin = new System.Windows.Forms.Padding(2);
            this.txtIDusuario.Name = "txtIDusuario";
            this.txtIDusuario.ReadOnly = true;
            this.txtIDusuario.Size = new System.Drawing.Size(68, 20);
            this.txtIDusuario.TabIndex = 43;
            // 
            // ViewActualizarEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 383);
            this.Controls.Add(this.txtIDusuario);
            this.Controls.Add(this.txtIdEmpleadoActualizar);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.estado);
            this.Controls.Add(this.cmbTipoEmpleadoActualizar);
            this.Controls.Add(this.cmbEstadoActualizar);
            this.Controls.Add(this.txtCorreoActualizar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.GrpUser);
            this.Controls.Add(this.txtDireccionActualizar);
            this.Controls.Add(this.mskDocumentoActualizar);
            this.Controls.Add(this.dtFechaNacActualizar);
            this.Controls.Add(this.txtTelefonoActualizar);
            this.Controls.Add(this.txtApellidoActualizar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNombreActualizar);
            this.Controls.Add(this.LblNombre);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ViewActualizarEmpleado";
            this.Text = "ViewActa";
            this.Load += new System.EventHandler(this.ViewActualizarEmpleado_Load);
            this.GrpUser.ResumeLayout(false);
            this.GrpUser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label estado;
        public System.Windows.Forms.ComboBox cmbTipoEmpleadoActualizar;
        public System.Windows.Forms.ComboBox cmbEstadoActualizar;
        public System.Windows.Forms.TextBox txtCorreoActualizar;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.GroupBox GrpUser;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.TextBox txtUsuarioEmpActualizar;
        public System.Windows.Forms.ComboBox cmbTipoUsuarioActualizar;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox txtDireccionActualizar;
        public System.Windows.Forms.MaskedTextBox mskDocumentoActualizar;
        public System.Windows.Forms.DateTimePicker dtFechaNacActualizar;
        public System.Windows.Forms.TextBox txtTelefonoActualizar;
        public System.Windows.Forms.TextBox txtApellidoActualizar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtNombreActualizar;
        public System.Windows.Forms.Label LblNombre;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtIdEmpleadoActualizar;
        public System.Windows.Forms.TextBox txtIDusuario;
    }
}