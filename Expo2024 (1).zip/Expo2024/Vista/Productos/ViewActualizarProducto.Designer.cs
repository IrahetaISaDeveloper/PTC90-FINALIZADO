﻿namespace Expo2024.Vista.Productos
{
    partial class ViewActualizarProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnActualizar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtActualizar_ID = new System.Windows.Forms.TextBox();
            this.cmbActualizar_Categoria = new System.Windows.Forms.ComboBox();
            this.Categoria_label = new System.Windows.Forms.Label();
            this.cmbActualizar_Proveedor = new System.Windows.Forms.ComboBox();
            this.Direccion_label = new System.Windows.Forms.Label();
            this.txtActualizar_Precio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtActualizar_Costo = new System.Windows.Forms.TextBox();
            this.NumeroTel_label = new System.Windows.Forms.Label();
            this.CorreoElec_Label = new System.Windows.Forms.Label();
            this.dtpAcualizar_Vencimiento = new System.Windows.Forms.DateTimePicker();
            this.nombre_Provee = new System.Windows.Forms.Label();
            this.txtActualizar_Nombre = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnActualizar
            // 
            this.btnActualizar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizar.Location = new System.Drawing.Point(223, 343);
            this.btnActualizar.Margin = new System.Windows.Forms.Padding(2);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(113, 38);
            this.btnActualizar.TabIndex = 72;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 71;
            this.label2.Text = "ID Producto";
            // 
            // txtActualizar_ID
            // 
            this.txtActualizar_ID.Location = new System.Drawing.Point(11, 32);
            this.txtActualizar_ID.Margin = new System.Windows.Forms.Padding(2);
            this.txtActualizar_ID.Name = "txtActualizar_ID";
            this.txtActualizar_ID.Size = new System.Drawing.Size(57, 25);
            this.txtActualizar_ID.TabIndex = 70;
            // 
            // cmbActualizar_Categoria
            // 
            this.cmbActualizar_Categoria.FormattingEnabled = true;
            this.cmbActualizar_Categoria.Location = new System.Drawing.Point(178, 290);
            this.cmbActualizar_Categoria.Margin = new System.Windows.Forms.Padding(2);
            this.cmbActualizar_Categoria.Name = "cmbActualizar_Categoria";
            this.cmbActualizar_Categoria.Size = new System.Drawing.Size(146, 25);
            this.cmbActualizar_Categoria.TabIndex = 69;
            // 
            // Categoria_label
            // 
            this.Categoria_label.AutoSize = true;
            this.Categoria_label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categoria_label.Location = new System.Drawing.Point(174, 260);
            this.Categoria_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Categoria_label.Name = "Categoria_label";
            this.Categoria_label.Size = new System.Drawing.Size(165, 20);
            this.Categoria_label.TabIndex = 68;
            this.Categoria_label.Text = "Categoria de Productos";
            // 
            // cmbActualizar_Proveedor
            // 
            this.cmbActualizar_Proveedor.FormattingEnabled = true;
            this.cmbActualizar_Proveedor.Location = new System.Drawing.Point(11, 290);
            this.cmbActualizar_Proveedor.Margin = new System.Windows.Forms.Padding(2);
            this.cmbActualizar_Proveedor.Name = "cmbActualizar_Proveedor";
            this.cmbActualizar_Proveedor.Size = new System.Drawing.Size(146, 25);
            this.cmbActualizar_Proveedor.TabIndex = 67;
            // 
            // Direccion_label
            // 
            this.Direccion_label.AutoSize = true;
            this.Direccion_label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Direccion_label.Location = new System.Drawing.Point(11, 260);
            this.Direccion_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Direccion_label.Name = "Direccion_label";
            this.Direccion_label.Size = new System.Drawing.Size(77, 20);
            this.Direccion_label.TabIndex = 66;
            this.Direccion_label.Text = "Proveedor";
            // 
            // txtActualizar_Precio
            // 
            this.txtActualizar_Precio.Location = new System.Drawing.Point(93, 221);
            this.txtActualizar_Precio.Margin = new System.Windows.Forms.Padding(2);
            this.txtActualizar_Precio.Name = "txtActualizar_Precio";
            this.txtActualizar_Precio.Size = new System.Drawing.Size(44, 25);
            this.txtActualizar_Precio.TabIndex = 65;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 199);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 20);
            this.label1.TabIndex = 64;
            this.label1.Text = "Precio Venta";
            // 
            // txtActualizar_Costo
            // 
            this.txtActualizar_Costo.Location = new System.Drawing.Point(11, 221);
            this.txtActualizar_Costo.Margin = new System.Windows.Forms.Padding(2);
            this.txtActualizar_Costo.Name = "txtActualizar_Costo";
            this.txtActualizar_Costo.Size = new System.Drawing.Size(44, 25);
            this.txtActualizar_Costo.TabIndex = 63;
            // 
            // NumeroTel_label
            // 
            this.NumeroTel_label.AutoSize = true;
            this.NumeroTel_label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumeroTel_label.Location = new System.Drawing.Point(11, 199);
            this.NumeroTel_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NumeroTel_label.Name = "NumeroTel_label";
            this.NumeroTel_label.Size = new System.Drawing.Size(47, 20);
            this.NumeroTel_label.TabIndex = 62;
            this.NumeroTel_label.Text = "Costo";
            // 
            // CorreoElec_Label
            // 
            this.CorreoElec_Label.AutoSize = true;
            this.CorreoElec_Label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CorreoElec_Label.Location = new System.Drawing.Point(11, 123);
            this.CorreoElec_Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CorreoElec_Label.Name = "CorreoElec_Label";
            this.CorreoElec_Label.Size = new System.Drawing.Size(154, 20);
            this.CorreoElec_Label.TabIndex = 61;
            this.CorreoElec_Label.Text = "Fecha de Vencimiento";
            // 
            // dtpAcualizar_Vencimiento
            // 
            this.dtpAcualizar_Vencimiento.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpAcualizar_Vencimiento.Location = new System.Drawing.Point(12, 155);
            this.dtpAcualizar_Vencimiento.Name = "dtpAcualizar_Vencimiento";
            this.dtpAcualizar_Vencimiento.Size = new System.Drawing.Size(321, 27);
            this.dtpAcualizar_Vencimiento.TabIndex = 60;
            // 
            // nombre_Provee
            // 
            this.nombre_Provee.AutoSize = true;
            this.nombre_Provee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre_Provee.Location = new System.Drawing.Point(11, 62);
            this.nombre_Provee.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nombre_Provee.Name = "nombre_Provee";
            this.nombre_Provee.Size = new System.Drawing.Size(154, 20);
            this.nombre_Provee.TabIndex = 59;
            this.nombre_Provee.Text = "Nombre del producto";
            // 
            // txtActualizar_Nombre
            // 
            this.txtActualizar_Nombre.Location = new System.Drawing.Point(11, 94);
            this.txtActualizar_Nombre.Margin = new System.Windows.Forms.Padding(2);
            this.txtActualizar_Nombre.Name = "txtActualizar_Nombre";
            this.txtActualizar_Nombre.Size = new System.Drawing.Size(321, 25);
            this.txtActualizar_Nombre.TabIndex = 58;
            // 
            // ViewActualizarProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(207)))), ((int)(((byte)(136)))));
            this.ClientSize = new System.Drawing.Size(350, 398);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtActualizar_ID);
            this.Controls.Add(this.cmbActualizar_Categoria);
            this.Controls.Add(this.Categoria_label);
            this.Controls.Add(this.cmbActualizar_Proveedor);
            this.Controls.Add(this.Direccion_label);
            this.Controls.Add(this.txtActualizar_Precio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtActualizar_Costo);
            this.Controls.Add(this.NumeroTel_label);
            this.Controls.Add(this.CorreoElec_Label);
            this.Controls.Add(this.dtpAcualizar_Vencimiento);
            this.Controls.Add(this.nombre_Provee);
            this.Controls.Add(this.txtActualizar_Nombre);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ViewActualizarProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewActualizarProducto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnActualizar;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtActualizar_ID;
        public System.Windows.Forms.ComboBox cmbActualizar_Categoria;
        public System.Windows.Forms.Label Categoria_label;
        public System.Windows.Forms.ComboBox cmbActualizar_Proveedor;
        public System.Windows.Forms.Label Direccion_label;
        public System.Windows.Forms.TextBox txtActualizar_Precio;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtActualizar_Costo;
        public System.Windows.Forms.Label NumeroTel_label;
        public System.Windows.Forms.Label CorreoElec_Label;
        public System.Windows.Forms.DateTimePicker dtpAcualizar_Vencimiento;
        public System.Windows.Forms.Label nombre_Provee;
        public System.Windows.Forms.TextBox txtActualizar_Nombre;
    }
}