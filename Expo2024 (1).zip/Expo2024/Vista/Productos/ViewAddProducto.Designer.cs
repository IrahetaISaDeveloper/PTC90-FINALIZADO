﻿namespace Expo2024.Vista.Productos
{
    partial class ViewAddProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuardar = new System.Windows.Forms.Button();
            this.cmbCategoria = new System.Windows.Forms.ComboBox();
            this.Categoria_label = new System.Windows.Forms.Label();
            this.cmbProveedor = new System.Windows.Forms.ComboBox();
            this.Direccion_label = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.NumeroTel_label = new System.Windows.Forms.Label();
            this.txtCosto = new System.Windows.Forms.TextBox();
            this.dtpVencimiento = new System.Windows.Forms.DateTimePicker();
            this.CorreoElec_Label = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.nombre_Provee = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGuardar
            // 
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Location = new System.Drawing.Point(223, 292);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(2);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(113, 38);
            this.btnGuardar.TabIndex = 64;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            // 
            // cmbCategoria
            // 
            this.cmbCategoria.FormattingEnabled = true;
            this.cmbCategoria.Location = new System.Drawing.Point(178, 230);
            this.cmbCategoria.Margin = new System.Windows.Forms.Padding(2);
            this.cmbCategoria.Name = "cmbCategoria";
            this.cmbCategoria.Size = new System.Drawing.Size(146, 25);
            this.cmbCategoria.TabIndex = 63;
            // 
            // Categoria_label
            // 
            this.Categoria_label.AutoSize = true;
            this.Categoria_label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categoria_label.Location = new System.Drawing.Point(174, 199);
            this.Categoria_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Categoria_label.Name = "Categoria_label";
            this.Categoria_label.Size = new System.Drawing.Size(165, 20);
            this.Categoria_label.TabIndex = 62;
            this.Categoria_label.Text = "Categoria de Productos";
            // 
            // cmbProveedor
            // 
            this.cmbProveedor.FormattingEnabled = true;
            this.cmbProveedor.Location = new System.Drawing.Point(11, 230);
            this.cmbProveedor.Margin = new System.Windows.Forms.Padding(2);
            this.cmbProveedor.Name = "cmbProveedor";
            this.cmbProveedor.Size = new System.Drawing.Size(146, 25);
            this.cmbProveedor.TabIndex = 61;
            // 
            // Direccion_label
            // 
            this.Direccion_label.AutoSize = true;
            this.Direccion_label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Direccion_label.Location = new System.Drawing.Point(11, 199);
            this.Direccion_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Direccion_label.Name = "Direccion_label";
            this.Direccion_label.Size = new System.Drawing.Size(77, 20);
            this.Direccion_label.TabIndex = 60;
            this.Direccion_label.Text = "Proveedor";
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(95, 158);
            this.txtPrecio.Margin = new System.Windows.Forms.Padding(2);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(44, 25);
            this.txtPrecio.TabIndex = 59;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(77, 136);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 20);
            this.label1.TabIndex = 58;
            this.label1.Text = "Precio Venta";
            // 
            // NumeroTel_label
            // 
            this.NumeroTel_label.AutoSize = true;
            this.NumeroTel_label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumeroTel_label.Location = new System.Drawing.Point(12, 136);
            this.NumeroTel_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NumeroTel_label.Name = "NumeroTel_label";
            this.NumeroTel_label.Size = new System.Drawing.Size(47, 20);
            this.NumeroTel_label.TabIndex = 57;
            this.NumeroTel_label.Text = "Costo";
            // 
            // txtCosto
            // 
            this.txtCosto.Location = new System.Drawing.Point(15, 158);
            this.txtCosto.Margin = new System.Windows.Forms.Padding(2);
            this.txtCosto.Name = "txtCosto";
            this.txtCosto.Size = new System.Drawing.Size(44, 25);
            this.txtCosto.TabIndex = 56;
            // 
            // dtpVencimiento
            // 
            this.dtpVencimiento.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpVencimiento.Location = new System.Drawing.Point(11, 91);
            this.dtpVencimiento.Name = "dtpVencimiento";
            this.dtpVencimiento.Size = new System.Drawing.Size(321, 27);
            this.dtpVencimiento.TabIndex = 55;
            // 
            // CorreoElec_Label
            // 
            this.CorreoElec_Label.AutoSize = true;
            this.CorreoElec_Label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CorreoElec_Label.Location = new System.Drawing.Point(11, 67);
            this.CorreoElec_Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CorreoElec_Label.Name = "CorreoElec_Label";
            this.CorreoElec_Label.Size = new System.Drawing.Size(154, 20);
            this.CorreoElec_Label.TabIndex = 54;
            this.CorreoElec_Label.Text = "Fecha de Vencimiento";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(11, 31);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(2);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(321, 25);
            this.txtNombre.TabIndex = 53;
            // 
            // nombre_Provee
            // 
            this.nombre_Provee.AutoSize = true;
            this.nombre_Provee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre_Provee.Location = new System.Drawing.Point(11, 9);
            this.nombre_Provee.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nombre_Provee.Name = "nombre_Provee";
            this.nombre_Provee.Size = new System.Drawing.Size(154, 20);
            this.nombre_Provee.TabIndex = 52;
            this.nombre_Provee.Text = "Nombre del producto";
            // 
            // ViewAddProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(207)))), ((int)(((byte)(136)))));
            this.ClientSize = new System.Drawing.Size(346, 342);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.cmbCategoria);
            this.Controls.Add(this.Categoria_label);
            this.Controls.Add(this.cmbProveedor);
            this.Controls.Add(this.Direccion_label);
            this.Controls.Add(this.txtPrecio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NumeroTel_label);
            this.Controls.Add(this.txtCosto);
            this.Controls.Add(this.dtpVencimiento);
            this.Controls.Add(this.CorreoElec_Label);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.nombre_Provee);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ViewAddProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewAddProducto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnGuardar;
        public System.Windows.Forms.ComboBox cmbCategoria;
        public System.Windows.Forms.Label Categoria_label;
        public System.Windows.Forms.ComboBox cmbProveedor;
        public System.Windows.Forms.Label Direccion_label;
        public System.Windows.Forms.TextBox txtPrecio;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label NumeroTel_label;
        public System.Windows.Forms.TextBox txtCosto;
        public System.Windows.Forms.DateTimePicker dtpVencimiento;
        public System.Windows.Forms.Label CorreoElec_Label;
        public System.Windows.Forms.TextBox txtNombre;
        public System.Windows.Forms.Label nombre_Provee;
    }
}