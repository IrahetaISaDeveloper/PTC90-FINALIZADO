﻿using Expo2024.Controlador.Productos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista.Productos
{
    public partial class ViewAdminProducto : Form
    {
        public ViewAdminProducto()
        {
            InitializeComponent();
            Controller_Producto admin = new Controller_Producto(this);
            Controller_Producto control = new Controller_Producto(this);
            dgvProductos.CellBeginEdit += dgvProductos_CellBeginEdit;
        }

        private void dgvProductos_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            e.Cancel = true;
        }

        private void cmsActualizarProducto_Click(object sender, EventArgs e)
        {

            ViewActualizarProducto from = new ViewActualizarProducto();

            if (dgvProductos.CurrentRow == null)
            {
                MessageBox.Show("Por favor, seleccione un producto para actualizar.");
                return;
            }

            string productoID = dgvProductos.CurrentRow.Cells["ID"].Value.ToString();
            string productoNombre = dgvProductos.CurrentRow.Cells["Nombre"].Value.ToString();
            string productoCosto = dgvProductos.CurrentRow.Cells["Costo"].Value.ToString();
            string productoPrecio = dgvProductos.CurrentRow.Cells["Precio"].Value.ToString();
            string productoVencimiento = dgvProductos.CurrentRow.Cells["fecha_Vencimiento"].Value.ToString();
            string productoCategoria = dgvProductos.CurrentRow.Cells["Categoria"].Value.ToString();
            string productoProveedor = dgvProductos.CurrentRow.Cells["Proveedor"].Value.ToString();

            ViewActualizarProducto form = new ViewActualizarProducto();
            form.txtActualizar_ID.Text = productoID;
            form.txtActualizar_Nombre.Text = productoNombre;
            form.txtActualizar_Costo.Text = productoCosto;
            form.txtActualizar_Precio.Text = productoPrecio;
            from.cmbActualizar_Categoria.SelectedText = productoCategoria;
            from.cmbActualizar_Proveedor.SelectedText = productoProveedor;

            DateTime vencimientoDate;
            if (DateTime.TryParse(productoVencimiento, out vencimientoDate))
            {
                form.dtpAcualizar_Vencimiento.Value = vencimientoDate;
            }
            else
            {
                MessageBox.Show("La fecha de vencimiento no es válida.");
            }
            form.Show();
        }


        private void ViewProducto_Load(object sender, EventArgs e)
        {

        }
    }
}
