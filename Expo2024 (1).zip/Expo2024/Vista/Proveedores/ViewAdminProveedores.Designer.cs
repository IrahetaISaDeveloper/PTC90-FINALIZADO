﻿namespace Expo2024.Vista.Proveedores
{
    partial class ViewAdminProveedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewAdminProveedores));
            this.panel7 = new System.Windows.Forms.Panel();
            this.panelNavegacion = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnInformes = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnVentas = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnProductos = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnProveedores = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnEmpleados = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnInicio = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnResrescar = new System.Windows.Forms.Button();
            this.BtnAgregar1 = new System.Windows.Forms.Button();
            this.dgvProvee = new System.Windows.Forms.DataGridView();
            this.ContexMenuProve = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmsEliminar = new System.Windows.Forms.ToolStripMenuItem();
            this.cmsActualizar = new System.Windows.Forms.ToolStripMenuItem();
            this.btnBuscarProv = new System.Windows.Forms.Button();
            this.txtBuscarProve = new System.Windows.Forms.TextBox();
            this.panelNavegacion.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProvee)).BeginInit();
            this.ContexMenuProve.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(172)))), ((int)(((byte)(80)))));
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(196, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1004, 60);
            this.panel7.TabIndex = 11;
            // 
            // panelNavegacion
            // 
            this.panelNavegacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(172)))), ((int)(((byte)(80)))));
            this.panelNavegacion.Controls.Add(this.panel9);
            this.panelNavegacion.Controls.Add(this.panel8);
            this.panelNavegacion.Controls.Add(this.panel6);
            this.panelNavegacion.Controls.Add(this.panel5);
            this.panelNavegacion.Controls.Add(this.panel4);
            this.panelNavegacion.Controls.Add(this.panel2);
            this.panelNavegacion.Controls.Add(this.panel3);
            this.panelNavegacion.Controls.Add(this.panel1);
            this.panelNavegacion.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelNavegacion.Location = new System.Drawing.Point(0, 0);
            this.panelNavegacion.Name = "panelNavegacion";
            this.panelNavegacion.Size = new System.Drawing.Size(196, 727);
            this.panelNavegacion.TabIndex = 10;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btnCerrarSesion);
            this.panel9.Location = new System.Drawing.Point(3, 444);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(190, 57);
            this.panel9.TabIndex = 10;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesion.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrarSesion.Image")));
            this.btnCerrarSesion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarSesion.Location = new System.Drawing.Point(0, 0);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(190, 57);
            this.btnCerrarSesion.TabIndex = 1;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnInformes);
            this.panel8.Location = new System.Drawing.Point(3, 381);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(190, 57);
            this.panel8.TabIndex = 5;
            // 
            // btnInformes
            // 
            this.btnInformes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInformes.Image = ((System.Drawing.Image)(resources.GetObject("btnInformes.Image")));
            this.btnInformes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInformes.Location = new System.Drawing.Point(0, 0);
            this.btnInformes.Name = "btnInformes";
            this.btnInformes.Size = new System.Drawing.Size(190, 57);
            this.btnInformes.TabIndex = 1;
            this.btnInformes.Text = "Informes";
            this.btnInformes.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnVentas);
            this.panel6.Location = new System.Drawing.Point(3, 255);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(190, 57);
            this.panel6.TabIndex = 6;
            // 
            // btnVentas
            // 
            this.btnVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentas.Image = ((System.Drawing.Image)(resources.GetObject("btnVentas.Image")));
            this.btnVentas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVentas.Location = new System.Drawing.Point(0, 0);
            this.btnVentas.Name = "btnVentas";
            this.btnVentas.Size = new System.Drawing.Size(190, 57);
            this.btnVentas.TabIndex = 1;
            this.btnVentas.Text = "Ventas";
            this.btnVentas.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnProductos);
            this.panel5.Location = new System.Drawing.Point(3, 192);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(190, 57);
            this.panel5.TabIndex = 5;
            // 
            // btnProductos
            // 
            this.btnProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductos.Image = ((System.Drawing.Image)(resources.GetObject("btnProductos.Image")));
            this.btnProductos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductos.Location = new System.Drawing.Point(0, 0);
            this.btnProductos.Name = "btnProductos";
            this.btnProductos.Size = new System.Drawing.Size(190, 57);
            this.btnProductos.TabIndex = 1;
            this.btnProductos.Text = "Productos";
            this.btnProductos.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnProveedores);
            this.panel4.Location = new System.Drawing.Point(3, 318);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(190, 57);
            this.panel4.TabIndex = 4;
            // 
            // btnProveedores
            // 
            this.btnProveedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProveedores.Image = ((System.Drawing.Image)(resources.GetObject("btnProveedores.Image")));
            this.btnProveedores.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProveedores.Location = new System.Drawing.Point(0, 0);
            this.btnProveedores.Name = "btnProveedores";
            this.btnProveedores.Size = new System.Drawing.Size(190, 57);
            this.btnProveedores.TabIndex = 1;
            this.btnProveedores.Text = "Proveedores";
            this.btnProveedores.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnEmpleados);
            this.panel2.Location = new System.Drawing.Point(3, 129);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(190, 57);
            this.panel2.TabIndex = 3;
            // 
            // btnEmpleados
            // 
            this.btnEmpleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmpleados.Image = ((System.Drawing.Image)(resources.GetObject("btnEmpleados.Image")));
            this.btnEmpleados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmpleados.Location = new System.Drawing.Point(0, 0);
            this.btnEmpleados.Name = "btnEmpleados";
            this.btnEmpleados.Size = new System.Drawing.Size(190, 57);
            this.btnEmpleados.TabIndex = 1;
            this.btnEmpleados.Text = "Empleados";
            this.btnEmpleados.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnInicio);
            this.panel3.Location = new System.Drawing.Point(3, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(190, 57);
            this.panel3.TabIndex = 2;
            // 
            // btnInicio
            // 
            this.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInicio.Image = ((System.Drawing.Image)(resources.GetObject("btnInicio.Image")));
            this.btnInicio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInicio.Location = new System.Drawing.Point(0, 0);
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.Size = new System.Drawing.Size(190, 57);
            this.btnInicio.TabIndex = 1;
            this.btnInicio.Text = "Inicio";
            this.btnInicio.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(190, 57);
            this.panel1.TabIndex = 0;
            // 
            // btnResrescar
            // 
            this.btnResrescar.Location = new System.Drawing.Point(214, 613);
            this.btnResrescar.Margin = new System.Windows.Forms.Padding(2);
            this.btnResrescar.Name = "btnResrescar";
            this.btnResrescar.Size = new System.Drawing.Size(170, 45);
            this.btnResrescar.TabIndex = 14;
            this.btnResrescar.Text = "Refrescar \r\nTabla";
            this.btnResrescar.UseVisualStyleBackColor = true;
            // 
            // BtnAgregar1
            // 
            this.BtnAgregar1.Location = new System.Drawing.Point(437, 613);
            this.BtnAgregar1.Name = "BtnAgregar1";
            this.BtnAgregar1.Size = new System.Drawing.Size(145, 45);
            this.BtnAgregar1.TabIndex = 13;
            this.BtnAgregar1.Text = "Agregar";
            this.BtnAgregar1.UseVisualStyleBackColor = true;
            // 
            // dgvProvee
            // 
            this.dgvProvee.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProvee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProvee.ContextMenuStrip = this.ContexMenuProve;
            this.dgvProvee.Location = new System.Drawing.Point(214, 90);
            this.dgvProvee.Name = "dgvProvee";
            this.dgvProvee.ReadOnly = true;
            this.dgvProvee.RowHeadersWidth = 62;
            this.dgvProvee.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProvee.Size = new System.Drawing.Size(974, 501);
            this.dgvProvee.TabIndex = 12;
            // 
            // ContexMenuProve
            // 
            this.ContexMenuProve.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.ContexMenuProve.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmsEliminar,
            this.cmsActualizar});
            this.ContexMenuProve.Name = "ContexMenuProve";
            this.ContexMenuProve.Size = new System.Drawing.Size(127, 48);
            // 
            // cmsEliminar
            // 
            this.cmsEliminar.Name = "cmsEliminar";
            this.cmsEliminar.Size = new System.Drawing.Size(126, 22);
            this.cmsEliminar.Text = "Eliminar";
            // 
            // cmsActualizar
            // 
            this.cmsActualizar.Name = "cmsActualizar";
            this.cmsActualizar.Size = new System.Drawing.Size(126, 22);
            this.cmsActualizar.Text = "Actualizar";
            // 
            // btnBuscarProv
            // 
            this.btnBuscarProv.Location = new System.Drawing.Point(1088, 624);
            this.btnBuscarProv.Name = "btnBuscarProv";
            this.btnBuscarProv.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarProv.TabIndex = 18;
            this.btnBuscarProv.Text = "Buscar";
            this.btnBuscarProv.UseVisualStyleBackColor = true;
            // 
            // txtBuscarProve
            // 
            this.txtBuscarProve.Location = new System.Drawing.Point(621, 624);
            this.txtBuscarProve.Name = "txtBuscarProve";
            this.txtBuscarProve.Size = new System.Drawing.Size(461, 25);
            this.txtBuscarProve.TabIndex = 17;
            // 
            // ViewAdminProveedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(207)))), ((int)(((byte)(136)))));
            this.ClientSize = new System.Drawing.Size(1200, 727);
            this.Controls.Add(this.btnBuscarProv);
            this.Controls.Add(this.txtBuscarProve);
            this.Controls.Add(this.btnResrescar);
            this.Controls.Add(this.BtnAgregar1);
            this.Controls.Add(this.dgvProvee);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panelNavegacion);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ViewAdminProveedores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Proveedores";
            this.panelNavegacion.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProvee)).EndInit();
            this.ContexMenuProve.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.Panel panelNavegacion;
        private System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.Button btnInformes;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.Button btnVentas;
        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Button btnProductos;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Button btnProveedores;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Button btnEmpleados;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Button btnInicio;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button btnResrescar;
        public System.Windows.Forms.Button BtnAgregar1;
        public System.Windows.Forms.DataGridView dgvProvee;
        public System.Windows.Forms.ContextMenuStrip ContexMenuProve;
        public System.Windows.Forms.ToolStripMenuItem cmsEliminar;
        public System.Windows.Forms.ToolStripMenuItem cmsActualizar;
        public System.Windows.Forms.Button btnBuscarProv;
        public System.Windows.Forms.TextBox txtBuscarProve;
    }
}