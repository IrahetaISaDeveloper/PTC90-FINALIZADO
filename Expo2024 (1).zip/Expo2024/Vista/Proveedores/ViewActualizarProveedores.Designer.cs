﻿namespace Expo2024.Vista.Proveedores
{
    partial class ViewActualizarProveedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.txtIDActualizar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbCategoriaActualizar = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTelefonoActualizar = new System.Windows.Forms.TextBox();
            this.txtDireccionActualizar = new System.Windows.Forms.TextBox();
            this.txtCorreoActualizar = new System.Windows.Forms.TextBox();
            this.txtNombreActualizar = new System.Windows.Forms.TextBox();
            this.btnActualizarDef = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(218, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 17);
            this.label6.TabIndex = 64;
            this.label6.Text = "ID Proveedor";
            // 
            // txtIDActualizar
            // 
            this.txtIDActualizar.Location = new System.Drawing.Point(221, 216);
            this.txtIDActualizar.Name = "txtIDActualizar";
            this.txtIDActualizar.Size = new System.Drawing.Size(84, 25);
            this.txtIDActualizar.TabIndex = 63;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 17);
            this.label5.TabIndex = 62;
            this.label5.Text = "Tipo Categoria";
            // 
            // cmbCategoriaActualizar
            // 
            this.cmbCategoriaActualizar.FormattingEnabled = true;
            this.cmbCategoriaActualizar.Location = new System.Drawing.Point(11, 215);
            this.cmbCategoriaActualizar.Name = "cmbCategoriaActualizar";
            this.cmbCategoriaActualizar.Size = new System.Drawing.Size(126, 25);
            this.cmbCategoriaActualizar.TabIndex = 61;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 60;
            this.label4.Text = "Correo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 59;
            this.label3.Text = "Telefono";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 17);
            this.label2.TabIndex = 58;
            this.label2.Text = "Direccion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 17);
            this.label1.TabIndex = 57;
            this.label1.Text = "Nombre";
            // 
            // txtTelefonoActualizar
            // 
            this.txtTelefonoActualizar.Location = new System.Drawing.Point(12, 107);
            this.txtTelefonoActualizar.Name = "txtTelefonoActualizar";
            this.txtTelefonoActualizar.Size = new System.Drawing.Size(458, 25);
            this.txtTelefonoActualizar.TabIndex = 56;
            // 
            // txtDireccionActualizar
            // 
            this.txtDireccionActualizar.Location = new System.Drawing.Point(11, 68);
            this.txtDireccionActualizar.Name = "txtDireccionActualizar";
            this.txtDireccionActualizar.Size = new System.Drawing.Size(458, 25);
            this.txtDireccionActualizar.TabIndex = 54;
            // 
            // txtCorreoActualizar
            // 
            this.txtCorreoActualizar.Location = new System.Drawing.Point(11, 148);
            this.txtCorreoActualizar.Name = "txtCorreoActualizar";
            this.txtCorreoActualizar.Size = new System.Drawing.Size(458, 25);
            this.txtCorreoActualizar.TabIndex = 55;
            // 
            // txtNombreActualizar
            // 
            this.txtNombreActualizar.Location = new System.Drawing.Point(12, 28);
            this.txtNombreActualizar.Name = "txtNombreActualizar";
            this.txtNombreActualizar.Size = new System.Drawing.Size(458, 25);
            this.txtNombreActualizar.TabIndex = 53;
            // 
            // btnActualizarDef
            // 
            this.btnActualizarDef.Location = new System.Drawing.Point(11, 268);
            this.btnActualizarDef.Name = "btnActualizarDef";
            this.btnActualizarDef.Size = new System.Drawing.Size(177, 45);
            this.btnActualizarDef.TabIndex = 52;
            this.btnActualizarDef.Text = "Actualizar";
            this.btnActualizarDef.UseVisualStyleBackColor = true;
            // 
            // ViewActualizarProveedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(207)))), ((int)(((byte)(136)))));
            this.ClientSize = new System.Drawing.Size(489, 339);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtIDActualizar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbCategoriaActualizar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTelefonoActualizar);
            this.Controls.Add(this.txtDireccionActualizar);
            this.Controls.Add(this.txtCorreoActualizar);
            this.Controls.Add(this.txtNombreActualizar);
            this.Controls.Add(this.btnActualizarDef);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ViewActualizarProveedores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Actualizar Proveedores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txtIDActualizar;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.ComboBox cmbCategoriaActualizar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtTelefonoActualizar;
        public System.Windows.Forms.TextBox txtDireccionActualizar;
        public System.Windows.Forms.TextBox txtCorreoActualizar;
        public System.Windows.Forms.TextBox txtNombreActualizar;
        public System.Windows.Forms.Button btnActualizarDef;
    }
}