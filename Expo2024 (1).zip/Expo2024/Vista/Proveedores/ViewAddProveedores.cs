﻿using Expo2024.Controlador.Proveedores;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista.Proveedores
{
    public partial class ViewAddProveedores : Form
    {
        public ViewAddProveedores()
        {
            InitializeComponent();
            ControllerAddProveedor control = new ControllerAddProveedor(this);
        }
    }
}
