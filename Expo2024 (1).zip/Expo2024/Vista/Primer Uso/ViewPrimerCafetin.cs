﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Controlador;

namespace Expo2024.Vista.Primer_Uso
{
    public partial class ViewPrimerCafetin : Form
    {
        public ViewPrimerCafetin()
        {
            InitializeComponent();
            ControllerPrimerCafetin admin = new ControllerPrimerCafetin(this);
        }
    }
}
