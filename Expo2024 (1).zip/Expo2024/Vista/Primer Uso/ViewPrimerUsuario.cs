﻿using Expo2024.Controlador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Vista.Primer_Uso
{
    public partial class ViewPrimerUsuario : Form
    {
        public ViewPrimerUsuario()
        {
            InitializeComponent();
            ControllerPrimerUsuario control = new ControllerPrimerUsuario(this);
        }
    }
}
