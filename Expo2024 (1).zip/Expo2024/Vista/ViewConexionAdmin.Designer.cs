﻿namespace Expo2024.Vista
{
    partial class ViewConexionAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewConexionAdmin));
            this.pnlAuth = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtContrasenaSQL = new System.Windows.Forms.TextBox();
            this.txtSQLAuthentication = new System.Windows.Forms.TextBox();
            this.btnGuardarInfo = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdDeshabilitarSeguridad = new System.Windows.Forms.RadioButton();
            this.rdHabilitarSeguridad = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombreBaseDatos = new System.Windows.Forms.TextBox();
            this.txtServidor = new System.Windows.Forms.TextBox();
            this.pnlAuth.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAuth
            // 
            this.pnlAuth.Controls.Add(this.label5);
            this.pnlAuth.Controls.Add(this.label3);
            this.pnlAuth.Controls.Add(this.txtContrasenaSQL);
            this.pnlAuth.Controls.Add(this.txtSQLAuthentication);
            this.pnlAuth.Location = new System.Drawing.Point(352, 215);
            this.pnlAuth.Name = "pnlAuth";
            this.pnlAuth.Size = new System.Drawing.Size(220, 116);
            this.pnlAuth.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Contraseña ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Usuario SQL Authentication";
            // 
            // txtContrasenaSQL
            // 
            this.txtContrasenaSQL.Location = new System.Drawing.Point(5, 83);
            this.txtContrasenaSQL.Name = "txtContrasenaSQL";
            this.txtContrasenaSQL.Size = new System.Drawing.Size(203, 25);
            this.txtContrasenaSQL.TabIndex = 6;
            // 
            // txtSQLAuthentication
            // 
            this.txtSQLAuthentication.Location = new System.Drawing.Point(5, 29);
            this.txtSQLAuthentication.Name = "txtSQLAuthentication";
            this.txtSQLAuthentication.Size = new System.Drawing.Size(203, 25);
            this.txtSQLAuthentication.TabIndex = 5;
            // 
            // btnGuardarInfo
            // 
            this.btnGuardarInfo.Location = new System.Drawing.Point(315, 341);
            this.btnGuardarInfo.Name = "btnGuardarInfo";
            this.btnGuardarInfo.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarInfo.TabIndex = 7;
            this.btnGuardarInfo.Text = "Guardar";
            this.btnGuardarInfo.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdDeshabilitarSeguridad);
            this.panel2.Controls.Add(this.rdHabilitarSeguridad);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(168, 215);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(188, 116);
            this.panel2.TabIndex = 6;
            // 
            // rdDeshabilitarSeguridad
            // 
            this.rdDeshabilitarSeguridad.AutoSize = true;
            this.rdDeshabilitarSeguridad.Location = new System.Drawing.Point(11, 73);
            this.rdDeshabilitarSeguridad.Name = "rdDeshabilitarSeguridad";
            this.rdDeshabilitarSeguridad.Size = new System.Drawing.Size(167, 21);
            this.rdDeshabilitarSeguridad.TabIndex = 4;
            this.rdDeshabilitarSeguridad.TabStop = true;
            this.rdDeshabilitarSeguridad.Text = "Deshabilitar Seguridad";
            this.rdDeshabilitarSeguridad.UseVisualStyleBackColor = true;
            // 
            // rdHabilitarSeguridad
            // 
            this.rdHabilitarSeguridad.AutoSize = true;
            this.rdHabilitarSeguridad.Location = new System.Drawing.Point(11, 39);
            this.rdHabilitarSeguridad.Name = "rdHabilitarSeguridad";
            this.rdHabilitarSeguridad.Size = new System.Drawing.Size(146, 21);
            this.rdHabilitarSeguridad.TabIndex = 3;
            this.rdHabilitarSeguridad.TabStop = true;
            this.rdHabilitarSeguridad.Text = "Habilitar Seguridad";
            this.rdHabilitarSeguridad.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Seguridad de Windows";
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(14, 136);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(390, 50);
            this.panel4.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtNombreBaseDatos);
            this.panel1.Controls.Add(this.txtServidor);
            this.panel1.Location = new System.Drawing.Point(168, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(404, 172);
            this.panel1.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nombre Base de Datos:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Servidor URL:";
            // 
            // txtNombreBaseDatos
            // 
            this.txtNombreBaseDatos.Location = new System.Drawing.Point(21, 87);
            this.txtNombreBaseDatos.Name = "txtNombreBaseDatos";
            this.txtNombreBaseDatos.Size = new System.Drawing.Size(369, 25);
            this.txtNombreBaseDatos.TabIndex = 2;
            // 
            // txtServidor
            // 
            this.txtServidor.Location = new System.Drawing.Point(21, 38);
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.Size = new System.Drawing.Size(369, 25);
            this.txtServidor.TabIndex = 1;
            // 
            // ViewConexionAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(584, 376);
            this.Controls.Add(this.btnGuardarInfo);
            this.Controls.Add(this.pnlAuth);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ViewConexionAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conexion a la Base de Datos";
            this.pnlAuth.ResumeLayout(false);
            this.pnlAuth.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel pnlAuth;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtContrasenaSQL;
        public System.Windows.Forms.TextBox txtSQLAuthentication;
        public System.Windows.Forms.Button btnGuardarInfo;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.RadioButton rdDeshabilitarSeguridad;
        public System.Windows.Forms.RadioButton rdHabilitarSeguridad;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtNombreBaseDatos;
        public System.Windows.Forms.TextBox txtServidor;
    }
}