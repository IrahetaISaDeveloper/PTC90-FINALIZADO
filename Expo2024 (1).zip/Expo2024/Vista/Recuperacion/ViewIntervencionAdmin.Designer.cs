﻿namespace Expo2024.Vista.Recuperacion
{
    partial class ViewIntervencionAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtUsuarioAdmin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtContrasenaAdmin = new System.Windows.Forms.TextBox();
            this.txtUsuarioEmpleado = new System.Windows.Forms.TextBox();
            this.txtContrasenaNueva = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCambiarContra = new System.Windows.Forms.Button();
            this.pnlCambioDeContra = new System.Windows.Forms.Panel();
            this.pnlCambioDeContra.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnVerificar
            // 
            this.btnVerificar.BackColor = System.Drawing.Color.White;
            this.btnVerificar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(96, 246);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(2);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(197, 41);
            this.btnVerificar.TabIndex = 8;
            this.btnVerificar.Text = "Verificar credenciales";
            this.btnVerificar.UseVisualStyleBackColor = false;
            // 
            // txtUsuarioAdmin
            // 
            this.txtUsuarioAdmin.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioAdmin.Location = new System.Drawing.Point(74, 112);
            this.txtUsuarioAdmin.Margin = new System.Windows.Forms.Padding(2);
            this.txtUsuarioAdmin.MaxLength = 50;
            this.txtUsuarioAdmin.Name = "txtUsuarioAdmin";
            this.txtUsuarioAdmin.Size = new System.Drawing.Size(238, 25);
            this.txtUsuarioAdmin.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(84, 77);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 21);
            this.label1.TabIndex = 6;
            this.label1.Text = "Usuario del administrador";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 27);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(316, 30);
            this.label2.TabIndex = 9;
            this.label2.Text = "Intervencion de Administrador";
            // 
            // txtContrasenaAdmin
            // 
            this.txtContrasenaAdmin.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContrasenaAdmin.Location = new System.Drawing.Point(74, 196);
            this.txtContrasenaAdmin.Margin = new System.Windows.Forms.Padding(2);
            this.txtContrasenaAdmin.MaxLength = 50;
            this.txtContrasenaAdmin.Name = "txtContrasenaAdmin";
            this.txtContrasenaAdmin.Size = new System.Drawing.Size(238, 25);
            this.txtContrasenaAdmin.TabIndex = 11;
            // 
            // txtUsuarioEmpleado
            // 
            this.txtUsuarioEmpleado.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioEmpleado.Location = new System.Drawing.Point(73, 74);
            this.txtUsuarioEmpleado.Margin = new System.Windows.Forms.Padding(2);
            this.txtUsuarioEmpleado.MaxLength = 50;
            this.txtUsuarioEmpleado.Name = "txtUsuarioEmpleado";
            this.txtUsuarioEmpleado.Size = new System.Drawing.Size(238, 25);
            this.txtUsuarioEmpleado.TabIndex = 13;
            // 
            // txtContrasenaNueva
            // 
            this.txtContrasenaNueva.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContrasenaNueva.Location = new System.Drawing.Point(73, 165);
            this.txtContrasenaNueva.Margin = new System.Windows.Forms.Padding(2);
            this.txtContrasenaNueva.MaxLength = 50;
            this.txtContrasenaNueva.Name = "txtContrasenaNueva";
            this.txtContrasenaNueva.Size = new System.Drawing.Size(238, 25);
            this.txtContrasenaNueva.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(76, 160);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(236, 21);
            this.label3.TabIndex = 16;
            this.label3.Text = "Contraseña del administrador";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(104, 31);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 21);
            this.label4.TabIndex = 17;
            this.label4.Text = "Usuario del empleado";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 118);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(257, 21);
            this.label5.TabIndex = 18;
            this.label5.Text = "Nueva contraseña del empleado";
            // 
            // btnCambiarContra
            // 
            this.btnCambiarContra.BackColor = System.Drawing.Color.White;
            this.btnCambiarContra.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCambiarContra.Location = new System.Drawing.Point(117, 220);
            this.btnCambiarContra.Margin = new System.Windows.Forms.Padding(2);
            this.btnCambiarContra.Name = "btnCambiarContra";
            this.btnCambiarContra.Size = new System.Drawing.Size(149, 41);
            this.btnCambiarContra.TabIndex = 21;
            this.btnCambiarContra.Text = "Cambiar contraseña";
            this.btnCambiarContra.UseVisualStyleBackColor = false;
            // 
            // pnlCambioDeContra
            // 
            this.pnlCambioDeContra.Controls.Add(this.btnCambiarContra);
            this.pnlCambioDeContra.Controls.Add(this.txtUsuarioEmpleado);
            this.pnlCambioDeContra.Controls.Add(this.label5);
            this.pnlCambioDeContra.Controls.Add(this.txtContrasenaNueva);
            this.pnlCambioDeContra.Controls.Add(this.label4);
            this.pnlCambioDeContra.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlCambioDeContra.Location = new System.Drawing.Point(0, 292);
            this.pnlCambioDeContra.Name = "pnlCambioDeContra";
            this.pnlCambioDeContra.Size = new System.Drawing.Size(374, 294);
            this.pnlCambioDeContra.TabIndex = 22;
            // 
            // ViewIntervencionAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(207)))), ((int)(((byte)(136)))));
            this.ClientSize = new System.Drawing.Size(374, 586);
            this.Controls.Add(this.pnlCambioDeContra);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtContrasenaAdmin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtUsuarioAdmin);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ViewIntervencionAdmin";
            this.Text = "Intervencion Administrador";
            this.pnlCambioDeContra.ResumeLayout(false);
            this.pnlCambioDeContra.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnVerificar;
        public System.Windows.Forms.TextBox txtUsuarioAdmin;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtContrasenaAdmin;
        public System.Windows.Forms.TextBox txtUsuarioEmpleado;
        public System.Windows.Forms.TextBox txtContrasenaNueva;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button btnCambiarContra;
        public System.Windows.Forms.Panel pnlCambioDeContra;
    }
}