﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Controlador;

namespace Expo2024.Vista.Recuperacion
{
    public partial class ViewMetodosRecuperacion : Form
    {
        public ViewMetodosRecuperacion()
        {
            InitializeComponent();
            ControllerMetodosRecu controlador = new ControllerMetodosRecu(this);
        }

        private void btnCorreo_Click(object sender, EventArgs e)
        {

        }
    }
}
