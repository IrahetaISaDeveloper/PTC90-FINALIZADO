﻿using Expo2024.Controlador.Login;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Controlador.Helper;
using Expo2024.Modelo;
using Expo2024.Vista;

namespace Expo2024.Vista
{
    public partial class ViewLogin : Form
    {
        public ViewLogin()
        {
            InitializeComponent();
            //Inicializar controlador en la vista
            ControllerLogin control = new ControllerLogin(this);
            Ocultar.Visible = false;
        }
    }
}
