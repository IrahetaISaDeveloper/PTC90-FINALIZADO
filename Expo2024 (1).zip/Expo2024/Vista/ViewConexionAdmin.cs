﻿using Expo2024.Controlador.Empleados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Controlador;

namespace Expo2024.Vista
{
    public partial class ViewConexionAdmin : Form
    {
        public ViewConexionAdmin(int origen)
        {
            InitializeComponent();
            ControllerAdminConexion admin = new ControllerAdminConexion(this, origen);
        }
    }
}
