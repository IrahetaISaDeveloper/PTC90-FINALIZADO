﻿using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DAO.Empleados;
using Expo2024.Vista.Recuperacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerCambiarContrasena
    {
        ViewCambiarContra vista;
        public ControllerCambiarContrasena(ViewCambiarContra vista,  string usuario)
        {
            this.vista = vista;
            this.vista.btnCambiarContra.Click += new EventHandler(CambiarClave);
        }

        void CambiarClave(object sender, EventArgs e)
        {
            if (!(string.IsNullOrEmpty(vista.txtPin.Text.Trim()) ||
                string.IsNullOrEmpty(vista.txtUsuario.Text.Trim()) ||
                string.IsNullOrEmpty(vista.txtContraseñaNueva.Text.Trim()) ||
                string.IsNullOrEmpty(vista.txtContraseñaConfirmada.Text.Trim())))
            {
                if (VerificarPIN())
                {
                    if (RestablecerClave())
                    {
                        MessageBox.Show("Contraseña restablecida con exito, ya puedes iniciar sesión con tu nueva contraseña.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        vista.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("La contraseña no pudo ser actualizada, vuelve a intentarlo, si el error persiste contacta al administrador del sistema.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("El PIN o el usuario son incorrectos, verifique la información proporcionada.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Todos los campos requeridos, favor completalos para establecer una nueva contraseña.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        bool VerificarPIN()
        {
            DAOEmpleados daoVerificar = new DAOEmpleados();
            ClasesComunes commonClasses = new ClasesComunes();
            daoVerificar.Pin = commonClasses.ComputeSha256Hash(vista.txtPin.Text.Trim());
            daoVerificar.User = vista.txtUsuario.Text.Trim();
            return daoVerificar.VerificarPINSeguridad();
        }

        bool RestablecerClave()
        {
            DAOEmpleados daoVerificar = new DAOEmpleados();
            ClasesComunes commonClasses = new ClasesComunes();

            if (vista.txtContraseñaNueva.Text.Trim().Equals(vista.txtContraseñaConfirmada.Text.Trim()))
            {
                if (commonClasses.EsValida((vista.txtContraseñaConfirmada.Text.Trim())))
                {
                    daoVerificar.Password = commonClasses.ComputeSha256Hash(vista.txtContraseñaConfirmada.Text.Trim());
                    daoVerificar.User = vista.txtUsuario.Text.Trim();
                    return daoVerificar.RestablecerContrasena();
                }
                else
                {
                    MessageBox.Show("Recuerda utilizar el formato corecto, verifique al lado izquierdo de la ventana.", "Proceso incompleto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }
            else
            {
                MessageBox.Show("Las contraseñas no coindicen.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}
