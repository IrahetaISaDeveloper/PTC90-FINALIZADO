﻿using DeliciosOS.Vista.Empleados;
using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DAO.Empleados;
using Expo2024.Vista.Empleados;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador.Empleados
{
    internal class ControllerAddEmpleados
    {
        private ViewAddEmpleado ObjAddEmpleado;
        private int accion;
        private string ValTipoEmpleado;

        // Variables para almacenar valores originales
        private string originalNombre;
        private string originalApellido;
        private string originalDireccion;
        private string originalTelefono;
        private string originalDocumento;
        private DateTime originalFechaNacimiento;
        private int originalTipoEmpleadoId;
        private int originalTipoUsuario;
        private int originalEstado;

        ViewActualizarEmpleado ActualVista = new ViewActualizarEmpleado();


        // Constructor del controlador para nuevos empleados
        public ControllerAddEmpleados(ViewAddEmpleado Vista, int accion)
        {
            ObjAddEmpleado = Vista;
            this.accion = accion;
            


            ObjAddEmpleado.Load += new EventHandler(CargaInicial);
            ObjAddEmpleado.btnAgregar.Click += new EventHandler(CrearUsuario);
            //ActualVista.btnActualizar.Click += new EventHandler(ActualizarRegistro);
            
        }

        // Constructor del controlador para empleados registrados
        public ControllerAddEmpleados(ViewAddEmpleado Vista, int accion, int idEmpleado, string nombre, string apellido, string direccion, string telefono, string documento, DateTime fechaNacimiento, string tipoEmpleado, int idUsuario, int idEstado)
        {
            ObjAddEmpleado = Vista;
            this.accion = accion;

            ValTipoEmpleado = tipoEmpleado;

            ObjAddEmpleado.Load += new EventHandler(CargaInicial);
            CargarValores(idEmpleado, nombre, apellido, direccion, telefono, documento, fechaNacimiento, idUsuario, idEstado);
            //ActualVista.btnActualizar.Click += new EventHandler(ActualizarRegistro);
            ObjAddEmpleado.btnAgregar.Click += new EventHandler(CrearUsuario);
            
        }

        // Metodo para estables, determinar y cargar los campos del ComboBox
        public void CargaInicial(object sender, EventArgs e)
        {
            CargarComboEmpleado();
            CargarComboEstado();
            CargarComboTipoUsuario();
        }

        public void CargarComboEmpleado()
        {
            DAOEmpleados objEmpleados = new DAOEmpleados();
            DataSet dtTipos = objEmpleados.ObtenerTiposEmpleado();
            ObjAddEmpleado.cmbTipoEmpleado.DataSource = dtTipos.Tables["tipoEmpleado"];
            ObjAddEmpleado.cmbTipoEmpleado.ValueMember = "idTipo_Empleado";
            ObjAddEmpleado.cmbTipoEmpleado.DisplayMember = "nombreTipo_Empleado";
        }

        public void CargarComboEstado()
        {
            DAOEmpleados objEmp = new DAOEmpleados();
            DataSet dtEstado = objEmp.ObtenerEstados();
            ObjAddEmpleado.cmbEstado.DataSource = dtEstado.Tables["estados"];
            ObjAddEmpleado.cmbEstado.ValueMember = "id_Estado";
            ObjAddEmpleado.cmbEstado.DisplayMember = "estado";
        }

        public void CargarComboTipoUsuario()
        {
            DAOEmpleados objEmplea = new DAOEmpleados();
            DataSet dtUsuario = objEmplea.ObtenerTipoUsuario();
            ObjAddEmpleado.cmbTipoUsuario.DataSource = dtUsuario.Tables["tipoUsuario"];
            ObjAddEmpleado.cmbTipoUsuario.ValueMember = "idTipo_Usuario";
            ObjAddEmpleado.cmbTipoUsuario.DisplayMember = "nombreTipo_Usuario";
        }
        


        // Metodo booleano para conocer si un argumento solo contiene numeros
        public bool EsNumeroTelefonoValido(string telefono)
        {
            string patronTelefono = @"^\d+$";
            return Regex.IsMatch(telefono, patronTelefono);
        }

        // Metodo para crear un registro en la tabla de empleados
        void CrearUsuario(object sender, EventArgs e)
        {
            DAOEmpleados DAOAdmin = new DAOEmpleados(); // Objeto que se usará para las operaciones de DB
            ClasesComunes common = new ClasesComunes();

            // Asignación de valores del formulario a DAOAdmin (Empleado y Usuario)
            DAOAdmin.Nombre = ObjAddEmpleado.txtNombre.Text.Trim();
            DAOAdmin.Apellido = ObjAddEmpleado.txtApellido.Text.Trim();
            DAOAdmin.Direccion = ObjAddEmpleado.txtDireccion.Text.Trim();
            DAOAdmin.Telefono = ObjAddEmpleado.txtTelefono.Text.Trim();
            DAOAdmin.Documento = ObjAddEmpleado.mskDocumento.Text.Trim();
            DAOAdmin.FechaNacimiento = ObjAddEmpleado.dtFechaNac.Value.Date;
            DAOAdmin.Usuario = ObjAddEmpleado.txtUsuarioEmp.Text.Trim(); // Nombre de usuario
            DAOAdmin.Correo = ObjAddEmpleado.txtCorreo.Text.Trim();
            DAOAdmin.IdTipoUsuario = (int)ObjAddEmpleado.cmbTipoUsuario.SelectedValue; // Tipo de usuario
            DAOAdmin.IdTipoEmpleado = (int)ObjAddEmpleado.cmbTipoEmpleado.SelectedValue; // Tipo de empleado
            DAOAdmin.IdEstado = (int)ObjAddEmpleado.cmbEstado.SelectedValue; // Estado del empleado

            // Llamada al método RegistrarNegocio() en DAOPU para realizar la inserción
            bool valorRetornado = DAOAdmin.RegistrarUsuario();

            if (valorRetornado == true)
            {
                // Mensaje de éxito
                MessageBox.Show("Los datos han sido registrados exitosamente",
                 "Proceso completado",
                 MessageBoxButtons.OK,
                 MessageBoxIcon.Information);

                // Mostrar credenciales de acceso
                MessageBox.Show($"Usuario administrador: {ObjAddEmpleado.txtUsuarioEmp.Text.Trim()}\nContraseña de usuario: {ObjAddEmpleado.txtUsuarioEmp.Text.Trim()}FU123",
                                "Credenciales de acceso",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);


            }
            else
            {
                // Mensaje de error en caso de falla en la inserción
                MessageBox.Show("Los datos no pudieron ser registrados",
                                "Proceso interrumpido",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        // Metodo para actualizar el empleados y sus atributos
        //public void ActualizarRegistro(object sender, EventArgs e)
        //{
        //    string telefono = ObjAddEmpleado.txtTelefono.Text.Trim();

        //    if (!EsNumeroTelefonoValido(telefono))
        //    {
        //        MessageBox.Show("El número de teléfono no es válido. Debe contener solo números", "Número de Teléfono Inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //        return;
        //    }

        //    if (!(string.IsNullOrEmpty(ObjAddEmpleado.txtNombre.Text.Trim()) ||
        //        string.IsNullOrEmpty(ObjAddEmpleado.txtApellido.Text.Trim()) ||
        //        string.IsNullOrEmpty(ObjAddEmpleado.mskDocumento.Text) ||
        //        string.IsNullOrEmpty(ObjAddEmpleado.txtDireccion.Text.Trim()) ||
        //        string.IsNullOrEmpty(ObjAddEmpleado.txtTelefono.Text.Trim())))
        //    {
        //        DAOEmpleados daoUpdate = new DAOEmpleados
        //        {
        //            IdEmpleado = (int)ObjAddEmpleado.Tag,
        //            Nombre = ObjAddEmpleado.txtNombre.Text.Trim(),
        //            Apellido = ObjAddEmpleado.txtApellido.Text.Trim(),
        //            Documento = ObjAddEmpleado.mskDocumento.Text.Trim(),
        //            Direccion = ObjAddEmpleado.txtDireccion.Text.Trim(),
        //            Telefono = ObjAddEmpleado.txtTelefono.Text.Trim(),
        //            FechaNacimiento = ObjAddEmpleado.dtFechaNac.Value.Date,
        //            IdTipoEmpleado = (int)ObjAddEmpleado.cmbTipoEmpleado.SelectedValue,
        //            IdEstado = (int)ObjAddEmpleado.cmbEstado.SelectedValue,
        //            IdTipoUsuario = (int)ObjAddEmpleado.cmbTipoUsuario.SelectedValue,
                    

        //        };

        //        int valorRetornado = daoUpdate.ActualizarEmpleado();
        //        if (valorRetornado == 1)
        //        {
        //            MessageBox.Show("Empleado actualizado exitosamente", "Proceso completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        }
        //        else
        //        {
        //            MessageBox.Show("Error al actualizar el empleado", "Proceso interrumpido", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Complete todos los campos obligatorios.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //    }
        //}

        // Metodo para cargar y guardar los valores del empleado al momento de realiza un evento de actualizacion
        public void CargarValores(int idEmpleado, string nombre, string apellido, string direccion, string telefono, string documento, DateTime fechaNacimiento, int idEstado, int idUsuario)
        {
            try
            {
                ObjAddEmpleado.Tag = idEmpleado;
                ObjAddEmpleado.Tag = idEstado;
                ObjAddEmpleado.Tag = idUsuario;
                ObjAddEmpleado.txtNombre.Text = nombre;
                ObjAddEmpleado.txtApellido.Text = apellido;
                ObjAddEmpleado.dtFechaNac.Value = fechaNacimiento;
                ObjAddEmpleado.mskDocumento.Text = documento;
                ObjAddEmpleado.txtDireccion.Text = direccion;
                ObjAddEmpleado.txtTelefono.Text = telefono;

                // Guardar los valores originales
                originalNombre = nombre;
                originalApellido = apellido;
                originalDireccion = direccion;
                originalTelefono = telefono;
                originalDocumento = documento;
                originalFechaNacimiento = fechaNacimiento;


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }
}