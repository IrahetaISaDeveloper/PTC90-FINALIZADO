﻿using Expo2024.Modelo.DTO.Empleados;
using Expo2024.Vista.Empleados;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Modelo.DAO.Empleados;
using DeliciosOS.Vista.Empleados;
using System.Runtime.CompilerServices;

namespace Expo2024.Controlador.Empleados
{
    internal class ControllerAdminEmpleados
    {
        private ViewAdminEmpleados vista;
        ViewAddEmpleado ObjAddUser;
        ViewActualizarEmpleado ActualVista;
        public ControllerAdminEmpleados(ViewAdminEmpleados vista)
        {
            this.vista = vista;

            // Asignar eventos
            this.vista.Load += new EventHandler(LoadData);
            this.vista.btnNuevo.Click += new EventHandler(CrearEmpleado);
            this.vista.btnBuscar.Click += new EventHandler(BuscarEmpleadoEvent);
            this.vista.contextDgvEmpleados.Items["cmsEditar"].Click += new EventHandler(EditarEmpleado);
            this.vista.contextDgvEmpleados.Items["cmsEliminar"].Click += new EventHandler(DeleteEmpleado);
        }
        public ControllerAdminEmpleados(ViewActualizarEmpleado ActualVista)
        {
            this.ActualVista = ActualVista;
            this.ActualVista.Load += new EventHandler(CargaInicial);
            this.ActualVista.btnActualizar.Click += new EventHandler(ActualizarRegistro);

        }
        public void ActualizarRegistro(object sender, EventArgs e)
        {
            string telefono = ActualVista.txtTelefonoActualizar.Text.Trim();

            if (!(string.IsNullOrEmpty(ActualVista.txtNombreActualizar.Text.Trim()) ||
                string.IsNullOrEmpty(ActualVista.txtApellidoActualizar.Text.Trim()) ||
                string.IsNullOrEmpty(ActualVista.mskDocumentoActualizar.Text) ||
                string.IsNullOrEmpty(ActualVista.txtDireccionActualizar.Text.Trim()) ||
                string.IsNullOrEmpty(ActualVista.txtTelefonoActualizar.Text.Trim())))
            {
                string usuario = ActualVista.txtUsuarioEmpActualizar.Text.Trim(); // Supongo que existe un campo para el usuario

                // Verificar si el usuario no está vacío
                if (string.IsNullOrEmpty(usuario))
                {
                    MessageBox.Show("El campo de usuario está vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DAOEmpleados daoUpdate = new DAOEmpleados
                {
                    IdEmpleado = int.Parse(ActualVista.txtIdEmpleadoActualizar.Text.Trim()),
                    Nombre = ActualVista.txtNombreActualizar.Text.Trim(),
                    Apellido = ActualVista.txtApellidoActualizar.Text.Trim(),
                    Documento = ActualVista.mskDocumentoActualizar.Text.Trim(),
                    Correo = ActualVista.txtCorreoActualizar.Text.Trim(),
                    Direccion = ActualVista.txtDireccionActualizar.Text.Trim(),
                    Telefono = ActualVista.txtTelefonoActualizar.Text.Trim(),
                    FechaNacimiento = ActualVista.dtFechaNacActualizar.Value.Date,
                    IdTipoEmpleado = (int)ActualVista.cmbTipoEmpleadoActualizar.SelectedValue,
                    IdEstado = (int)ActualVista.cmbEstadoActualizar.SelectedValue,
                    IdTipoUsuario = (int)ActualVista.cmbTipoUsuarioActualizar.SelectedValue,
                    IdUsuario = int.Parse(ActualVista.txtIDusuario.Text.Trim()),
                    Usuario = ActualVista.txtUsuarioEmpActualizar.Text.Trim(),
                };

                int valorRetornado = daoUpdate.ActualizarEmpleado();
                if (valorRetornado == 1)
                {
                    MessageBox.Show("Empleado actualizado exitosamente", "Proceso completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error al actualizar el empleado", "Proceso interrumpido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Complete todos los campos obligatorios.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void CargaInicial(object sender, EventArgs e)
        {
            CargarComboEmpleado_Actualizar();
            CargarComboEstado_Actualizar();
            CargarComboTipoUsuario_Actualizar();
        }
         // los de actualizar combo box
        public void CargarComboEmpleado_Actualizar()
        {
            DAOEmpleados objEmpleados = new DAOEmpleados();
            DataSet dtTipos = objEmpleados.ObtenerTiposEmpleado();
            ActualVista.cmbTipoEmpleadoActualizar.DataSource = dtTipos.Tables["tipoEmpleado"];
            ActualVista.cmbTipoEmpleadoActualizar.ValueMember = "idTipo_Empleado";
            ActualVista.cmbTipoEmpleadoActualizar.DisplayMember = "nombreTipo_Empleado";
        }

        public void CargarComboEstado_Actualizar()
        {
            DAOEmpleados objEmp = new DAOEmpleados();
            DataSet dtEstado = objEmp.ObtenerEstados();
            ActualVista.cmbEstadoActualizar.DataSource = dtEstado.Tables["estados"];
            ActualVista.cmbEstadoActualizar.ValueMember = "id_Estado";
            ActualVista.cmbEstadoActualizar.DisplayMember = "estado";
        }

        public void CargarComboTipoUsuario_Actualizar()
        {
            DAOEmpleados objEmplea = new DAOEmpleados();
            DataSet dtUsuario = objEmplea.ObtenerTipoUsuario();
            ActualVista.cmbTipoUsuarioActualizar.DataSource = dtUsuario.Tables["tipoUsuario"];
            ActualVista.cmbTipoUsuarioActualizar.ValueMember = "idTipo_Usuario";
            ActualVista.cmbTipoUsuarioActualizar.DisplayMember = "nombreTipo_Usuario";
        }

        // Cargar datos al iniciar la vista
        public void LoadData(object sender, EventArgs e)
        {
            llenarData();
        }

        // Refrescar el DataGridView con los empleados
        private void RefrescarData()
        {
            llenarData();
        }

        // Evento de búsqueda de empleados
        private void BuscarEmpleadoEvent(object sender, EventArgs e)
        {
            BuscarEmpleado();
        }

        // Evento para buscar empleados según un argumento X
        private void BuscarEmpleado()
        {
            DAOEmpleados dao = new DAOEmpleados();
            DataTable empleados = dao.BuscarEmpleado(vista.txtSearch.Text.Trim());

            if (empleados != null && empleados.Rows.Count > 0)
            {
                vista.dgvEmpleados.DataSource = empleados;
            }
            else
            {
                MessageBox.Show("No se encontraron empleados con ese criterio.");
            }
        }

        // Evento para agregar un nuevo empleado
        private void CrearEmpleado(object sender, EventArgs e)
        {
            ViewAddEmpleado agregarEmpleadoForm = new ViewAddEmpleado(1);
            agregarEmpleadoForm.ShowDialog();
            RefrescarData();
        }

        // Evento para editar un empleado seleccionado en el DataGridView
        private void EditarEmpleado(object sender, EventArgs e)
        {

            DAOEmpleados daoUpdate = new DAOEmpleados();
           

            //Capturando los valores de la fila seleccionada
            string idEmpleado = vista.dgvEmpleados.CurrentRow.Cells["ID_Empleado"].Value.ToString();
            string idUsuario = vista.dgvEmpleados.CurrentRow.Cells["UsuarioID"].Value.ToString();
            string nombre = vista.dgvEmpleados.CurrentRow.Cells["Nombre"].Value.ToString();
            string apellido = vista.dgvEmpleados.CurrentRow.Cells["Apellido"].Value.ToString();
            string direccion = vista.dgvEmpleados.CurrentRow.Cells["Direccion"].Value.ToString();
            string documento = vista.dgvEmpleados.CurrentRow.Cells["Documento"].Value.ToString();
            string fechaNac = vista.dgvEmpleados.CurrentRow.Cells["FechaNacimiento"].Value.ToString();
            string telefono = vista.dgvEmpleados.CurrentRow.Cells["Telefono"].Value.ToString();
            
            //string correo = vista.dgvEmpleados.CurrentRow.Cells["Correo"].Value.ToString();
            //string estadoUsuario = vista.dgvEmpleados.CurrentRow.Cells["id_Estado"].Value.ToString();
            //string tipoempleado = vista.dgvEmpleados.CurrentRow.Cells["idTipo_Empleado"].Value.ToString();
            //string usuario = vista.dgvEmpleados.CurrentRow.Cells["id_Usuario"].Value.ToString();
            //string rol = vista.dgvEmpleados.CurrentRow.Cells[""].Value.ToString();

            ViewActualizarEmpleado ActualVista = new ViewActualizarEmpleado();

            ActualVista.txtIdEmpleadoActualizar.Text = idEmpleado;
            ActualVista.txtNombreActualizar.Text = nombre;
            ActualVista.txtApellidoActualizar.Text = apellido;
            ActualVista.dtFechaNacActualizar.Value = DateTime.Parse(fechaNac);
            ActualVista.mskDocumentoActualizar.Text = documento;
            ActualVista.txtDireccionActualizar.Text  = direccion;
            ActualVista.txtTelefonoActualizar.Text= telefono;
            ActualVista.txtIDusuario.Text = idUsuario;

            ActualVista.Show();
            RefrescarData();
        }



        // Evento para eliminar un empleado
        private void DeleteEmpleado(object sender, EventArgs e)
        {
            int pos = vista.dgvEmpleados.CurrentRow.Index;
            int idEmpleado = int.Parse(vista.dgvEmpleados[0, pos].Value.ToString());
            int idUsuario = int.Parse(vista.dgvEmpleados[8, pos].Value.ToString());

            if (MessageBox.Show("¿Está seguro que desea eliminar este empleado?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                DAOEmpleados dao = new DAOEmpleados();
                dao.IdEmpleado = idEmpleado;
                dao.IdUsuario = idUsuario;
                int resultado = dao.EliminarEmpleado();

                if (resultado == 1)
                {

                    MessageBox.Show("Empleado eliminado correctamente.");
                    RefrescarData();
                    int resultado2 = dao.EliminarUsuario();
                    if (resultado2 == 1)
                    {
                        MessageBox.Show("Usuario eliminado correctamente.");
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar el Usuario.");
                    }
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el empleado.");
                }

            }
            RefrescarData();

        }

        public void llenarData()
        {
            DAOEmpleados daoEmpleado = new DAOEmpleados();
            DataSet ds = daoEmpleado.ObtenerData();
            vista.dgvEmpleados.DataSource = ds.Tables["vista_empleados_usuariosDef"];
        }



    }
}
