﻿using Expo2024.Vista.Empleados;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeliciosOS.Controlador.Empleados
{
    internal class ControllerEmpleados 
    {
        
        
    }
}
