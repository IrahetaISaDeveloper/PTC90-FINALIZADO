﻿using Expo2024.Vista.Recuperacion;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Modelo;
using Expo2024.Modelo.DAO;
using Expo2024.Controlador.Helper;

namespace Expo2024.Controlador
{
    internal class ControllerIntervencionAdministrador
    {
            ViewIntervencionAdmin ObjIntervencion;

            public ControllerIntervencionAdministrador(ViewIntervencionAdmin vista)
            {
                ObjIntervencion = vista;
                ObjIntervencion.btnVerificar.Click += new EventHandler(VerificarContraAdmin);
                ObjIntervencion.btnCambiarContra.Click += new EventHandler(CambiarContraUsuario);
                ObjIntervencion.pnlCambioDeContra.Enabled = false;
        }

        // Verificación de la contraseña del administrador
        public void VerificarContraAdmin(object sender, EventArgs e)
        {
            DAOIntervencionAdministrador dao = new DAOIntervencionAdministrador();

            // Obtener el nombre de usuario del administrador desde el campo de texto
            string nombreUsuarioAdmin = ObjIntervencion.txtUsuarioAdmin.Text.Trim();
            

            // Verificar si el nombre de usuario pertenece a un administrador
            bool esAdminValido = dao.VerificarContraAdministrador(nombreUsuarioAdmin);

            if (esAdminValido)
            {
                MessageBox.Show("Usuario Administrador Correcto. Bienvenido.", "Bienvenido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Habilitar los campos para cambiar la contraseña de otro usuario
                ObjIntervencion.pnlCambioDeContra.Enabled = true;
            }
            else
            {
                MessageBox.Show("El usuario no tiene permisos de administrador.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Cambiar la contraseña del usuario objetivo
        public void CambiarContraUsuario(object sender, EventArgs e)
            {
                // Verifica si los campos están completos
                if (!string.IsNullOrEmpty(ObjIntervencion.txtUsuarioEmpleado.Text.Trim()) &&
                    !string.IsNullOrEmpty(ObjIntervencion.txtContrasenaNueva.Text.Trim()))
                {
                    DAOIntervencionAdministrador dao = new DAOIntervencionAdministrador();
                    ClasesComunes commonClasses = new ClasesComunes();

                    // Encriptar la nueva contraseña
                    string nuevaContraEncriptada = commonClasses.ComputeSha256Hash(ObjIntervencion.txtContrasenaNueva.Text.Trim());

                    dao.Usuario = ObjIntervencion.txtUsuarioEmpleado.Text.Trim();
                    dao.Password = nuevaContraEncriptada;

                    bool resultado = dao.CambiarContraUsuario();

                    if (resultado)
                    {
                        MessageBox.Show("Contraseña del usuario cambiada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Error al cambiar la contraseña. Verifique el nombre de usuario.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Por favor, complete todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
    }
}
