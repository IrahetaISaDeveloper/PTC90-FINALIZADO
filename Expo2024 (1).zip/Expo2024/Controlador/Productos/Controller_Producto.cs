﻿using Expo2024.Vista.Productos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Modelo.DAO.Productos;

namespace Expo2024.Controlador.Productos
{
    internal class Controller_Producto
    {
        ViewAddProducto vista;

        public Controller_Producto(ViewAddProducto vista)
        {
            this.vista = vista;
            vista.Load += new EventHandler(CargaInicial);
            vista.btnGuardar.Click += new EventHandler(Guardar);
        }

        public void CargaInicial(object sender, EventArgs e)
        {
            llenarProveedor();
            llenarCategoria();
        }

        public void llenarProveedor()
        {
            DAOProductos daoCombo = new DAOProductos();
            DataSet ds = daoCombo.ObtenerProveedor();
            vista.cmbProveedor.DataSource = ds.Tables["proveedor"];
            vista.cmbProveedor.DisplayMember = "Nombre";
            vista.cmbProveedor.ValueMember = "id_Proveedor";
        }

        public void llenarCategoria()
        {
            DAOProductos daoCombo = new DAOProductos();
            DataSet ds = daoCombo.ObtenerCategoriaProveedor();
            vista.cmbCategoria.DataSource = ds.Tables["categoria"];
            vista.cmbCategoria.DisplayMember = "Nombre";
            vista.cmbCategoria.ValueMember = "ID_Categoria";
        }
        public void Guardar(object sender, EventArgs e) //Funcionamiento de guardar y sus validaciones
        {
            try
            {
                // Validaciones de entrada
                if (string.IsNullOrWhiteSpace(vista.txtNombre.Text))
                {
                    MessageBox.Show("El nombre del producto es obligatorio.");
                    return;
                }

                if (!decimal.TryParse(vista.txtCosto.Text.Trim(), out decimal costo))
                {
                    MessageBox.Show("El costo debe ser un número decimal válido.");
                    return;
                }

                if (!decimal.TryParse(vista.txtPrecio.Text.Trim(), out decimal precio))
                {
                    MessageBox.Show("El precio debe ser un número decimal válido.");
                    return;
                }

                if (vista.dtpVencimiento.Value <= DateTime.Now)
                {
                    MessageBox.Show("La fecha de vencimiento debe ser una fecha futura.");
                    return;
                }

                if (vista.cmbCategoria.SelectedValue == null || vista.cmbProveedor.SelectedValue == null)
                {
                    MessageBox.Show("Debe seleccionar una categoría y un proveedor.");
                    return;
                }

                DAOProductos daoInsert = new DAOProductos
                {
                    Nombre = vista.txtNombre.Text.Trim(),
                    Costo = costo,
                    Precio = precio,
                    Fecha_Vencimiento = vista.dtpVencimiento.Value,
                    Id_Categoria = (int)vista.cmbCategoria.SelectedValue,
                    Id_Proveedor = (int)vista.cmbProveedor.SelectedValue
                };

                int resultado = daoInsert.GuardarProducto();

                if (resultado > 0)
                {
                    MessageBox.Show("Producto guardado exitosamente.");
                }
                else
                {
                    MessageBox.Show("No se pudo guardar el producto.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        //
        //
        // PARTE DE ELIMINAR
        //
        //
        ViewAdminProducto objProducto;
        public Controller_Producto(ViewAdminProducto objProducto)
        {
            this.objProducto = objProducto;
            objProducto.Load += new EventHandler(Cargar);
            objProducto.btnAjuste.Click += new EventHandler(btnAjuste_Click);
            objProducto.cmsEliminarProducto.Click += new EventHandler(Eliminar);
            //objProducto.cmsActualizarProducto.Click += new EventHandler(cargar);
            objProducto.btnBuscador.Click += new EventHandler(BucarProducto);
            objProducto.btnRefrescar.Click += new EventHandler(RefrescarTabla);
        }

        public void Cargar(object sender, EventArgs e)
        {
            llenarData();
        }

        public void llenarData()
        {
            DAOProductos daoProducto = new DAOProductos();
            DataSet ds = daoProducto.ObtenerData();
            objProducto.dgvProductos.DataSource = ds.Tables["vistaProductos"];
        }
        public void RefrescarTabla(object sender, EventArgs e)
        {
            llenarData();
        }

        private void BucarProducto(object sender, EventArgs e) //Buscador 
        {
            DAOProductos objbuscar = new DAOProductos();
            DataSet ds = objbuscar.Buscar(objProducto.txtBuscador.Text.Trim());
            objProducto.dgvProductos.DataSource = ds.Tables["productos"];
        }
        private void btnAjuste_Click(object sender, EventArgs e) //evento click para llamar el formulario de insercion de datos
        {
            ViewAddProducto form = new ViewAddProducto();
            form.Show();
        }


        private void Eliminar(object sender, EventArgs e)  //Funcionamiento de eliminar con todo y sus validaciones
        {
            try
            {
                if (objProducto.dgvProductos.SelectedCells.Count == 0)
                {
                    MessageBox.Show("Debe seleccionar un producto para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult confirmacion = MessageBox.Show("¿Esta seguro de que desea eliminar este producto?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (confirmacion == DialogResult.No)
                {
                    return;
                }

                DAOProductos daoEliminar = new DAOProductos();
                daoEliminar.Id_Producto = (int)objProducto.dgvProductos.SelectedCells[0].Value;

                // Intentar eliminar el producto
                int valorRetornado = daoEliminar.EliminarProducto();
                if (valorRetornado == 1)
                {
                    MessageBox.Show("Registro eliminado", "Acción completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el producto: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //
        //
        // PARTE DE Actualizar
        //
        //

        ViewActualizarProducto objvista;
        public Controller_Producto(ViewActualizarProducto objvista)
        {
            this.objvista = objvista;



            objvista.Load += new EventHandler(cargar1);
            objvista.btnActualizar.Click += new EventHandler(Actualizar);


        }

        public void cargar1(object sender, EventArgs e)
        {
            llenarProveedor_Actualizar();
            llenarCategoria_Actualizar();
        }

        public void llenarProveedor_Actualizar()
        {
            DAOProductos daoCombo = new DAOProductos();
            DataSet ds = daoCombo.ObtenerProveedor();
            objvista.cmbActualizar_Proveedor.DataSource = ds.Tables["proveedor"];
            objvista.cmbActualizar_Proveedor.DisplayMember = "Nombre";
            objvista.cmbActualizar_Proveedor.ValueMember = "id_Proveedor";
        }

        public void llenarCategoria_Actualizar()
        {
            DAOProductos daoCombo = new DAOProductos();
            DataSet ds = daoCombo.ObtenerCategoriaProveedor();
            objvista.cmbActualizar_Categoria.DataSource = ds.Tables["categoria"];
            objvista.cmbActualizar_Categoria.DisplayMember = "Nombre";
            objvista.cmbActualizar_Categoria.ValueMember = "ID_Categoria";
        }

        //funcionamiento de actualizar con todo y sus validaciones
        private void Actualizar(object sender, EventArgs e)
        {
            DAOProductos daoUpdate = new DAOProductos();
            try
            {
                daoUpdate.Id_Producto = int.Parse(objvista.txtActualizar_ID.Text.Trim());

                string nombre = objvista.txtActualizar_Nombre.Text.Trim();
                if (string.IsNullOrEmpty(nombre))
                {
                    MessageBox.Show("El nombre no puede estar vacio", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                else if (nombre.Length > 50)
                {
                    MessageBox.Show("El nombre no puede tener mas de 50 caracteres", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                daoUpdate.Nombre = nombre;

                if (!decimal.TryParse(objvista.txtActualizar_Costo.Text.Trim(), out decimal costo) || costo <= 0)
                {
                    MessageBox.Show("El costo debe ser un valor decimal", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                daoUpdate.Costo = costo;

                if (!decimal.TryParse(objvista.txtActualizar_Precio.Text.Trim(), out decimal precio) || precio <= 0)
                {
                    MessageBox.Show("El precio debe ser un valor decimal", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                daoUpdate.Precio = precio;

                DateTime fechaVencimiento = objvista.dtpAcualizar_Vencimiento.Value;
                if (fechaVencimiento < DateTime.Now)
                {
                    MessageBox.Show("La fecha de vencimiento no puede ser anterior a la fecha actual", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                daoUpdate.Fecha_Vencimiento = fechaVencimiento;

                if (objvista.cmbActualizar_Categoria.SelectedValue == null)
                {
                    MessageBox.Show("Debe seleccionar una categoria", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                daoUpdate.Id_Categoria = (int)objvista.cmbActualizar_Categoria.SelectedValue;

                if (objvista.cmbActualizar_Proveedor.SelectedValue == null)
                {
                    MessageBox.Show("Debe seleccionar un proveedor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                daoUpdate.Id_Proveedor = (int)objvista.cmbActualizar_Proveedor.SelectedValue;


                int valorRetornado = daoUpdate.Actualizar();
                if (valorRetornado == 1)
                {
                    MessageBox.Show("Los datos han sido actualizados exitosamente", "Proceso completado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else if (valorRetornado == 2)
                {
                    MessageBox.Show("No se encontraron registros para actualizar", "Proceso completado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en el formato de los datos ingresados: {ex.Message}", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
