﻿using Expo2024.Modelo.DAO;
using Expo2024.Modelo.DAO.Empleados;
using Expo2024.Vista;
using Expo2024.Vista.Recuperacion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerCrearPreguntas
    {
        ViewCreacionPreguntas objCpreguntas;

        public ControllerCrearPreguntas(ViewCreacionPreguntas vista)
        {
            objCpreguntas = vista;
            objCpreguntas.btnGuardar.Click += new EventHandler(GuardarPreguntas);
            objCpreguntas.btnComprobarCredenciales.Click += new EventHandler(ComprobarCredenciales);
            objCpreguntas.pnlPreguntas.Enabled = false;
        }

        public void ComprobarCredenciales(object sender, EventArgs e)
        {
            DAOPreguntas dao = new DAOPreguntas();

            string nombreUsuario = objCpreguntas.txtUsuario.Text.Trim();
            string contrasena = objCpreguntas.txtContrasena.Text.Trim();

            bool esValido = dao.VerificarUsuarioYContra(nombreUsuario, contrasena);

            if (esValido)
            {
                MessageBox.Show("Usuario Correcto. Bienvenido.", "Bienvenido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                objCpreguntas.pnlPreguntas.Enabled = true;
            }
            else
            {
                MessageBox.Show("El usuario no tiene permisos o credenciales incorrectas.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void GuardarPreguntas(object sender, EventArgs e)
        {
            DAOPreguntas DAOQuestions = new DAOPreguntas();
            DAOQuestions.User = objCpreguntas.txtUsuario.Text.Trim();
            DAOQuestions.Pregunta1 = objCpreguntas.txt1erRespuesta.Text.Trim();
            DAOQuestions.Pregunta2 = objCpreguntas.txt2daRespuesta.Text.Trim();
            DAOQuestions.Pregunta3 = objCpreguntas.txt3eraRespuesta.Text.Trim();

            int ValorRetornado = DAOQuestions.IngresarPreguntas();
            if (ValorRetornado == 1)
            {
                MessageBox.Show("Preguntas ingresadas", "Proceso Completo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                objCpreguntas.Hide();
                ViewLogin openForm = new ViewLogin();
                openForm.Show();
            }
            else
            {
                MessageBox.Show("Preguntas no ingresadas", "Proceso Interrumpido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
