﻿using System;
using System.Net.Mail;
using System.Net;
using System.Windows.Forms;
using Expo2024.Modelo.DAO;
using SendGrid;
using SendGrid.Helpers.Mail;
using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DAO.Empleados;
using Expo2024.Vista.Recuperacion;
using System.Linq;

namespace Expo2024.Controlador
{
    internal class ControllerRecuperarPorCorreo
    {
        ViewRecuperacionCorreo ObjCorreo;

        public ControllerRecuperarPorCorreo(ViewRecuperacionCorreo vista)
        {
            ObjCorreo = vista;
            ObjCorreo.btnEnviar.Click += new EventHandler(EnviarCorreoAsync);
            ObjCorreo.btnCambiarContra.Click += new EventHandler(CambiarClave);
        }

        public static string codigoAleatorio;
        public static string correoUsuario;
        public static string usuario;

        public async void EnviarCorreoAsync(Object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ObjCorreo.txtCorreo.Text.Trim()))
            {
                DAOCambiarContra daoContra = new DAOCambiarContra();
                daoContra.Email = ObjCorreo.txtCorreo.Text;

                // Obtener el nombre de usuario asociado al correo
                string usuarioObtenido = daoContra.ComprobarUsuario(daoContra.Email);

                if (usuarioObtenido != null)
                {
                    if (!IsValidEmail(daoContra.Email))
                    {
                        MessageBox.Show("Ingrese un correo electrónico válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Generar el código aleatorio
                    codigoAleatorio = GenerateRandomCode(6);
                    correoUsuario = daoContra.Email; // Guardar el correo del usuario
                    usuario = usuarioObtenido; // Guardar el nombre del usuario obtenido

                    try
                    {
                        // Enviar el correo con el código
                        var apiKey = "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";
                        var client = new SendGridClient(apiKey);
                        var from = new EmailAddress("recepcion@pro-office.com.sv", "Sistema gestión de cafetines");
                        var subject = "Recuperación de Contraseña";
                        var to = new EmailAddress(daoContra.Email);
                        var plainTextContent = "Código recibido es: " + codigoAleatorio;
                        var htmlContent = "Código recibido es:<b>" + codigoAleatorio + "</b>";
                        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);

                        var response = await client.SendEmailAsync(msg).ConfigureAwait(false);

                        if (response.StatusCode.ToString() == "Accepted")
                        {
                            MessageBox.Show("Se ha enviado un correo con el código de recuperación.", "Sistema de gestión de cafetines", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Habilitar los campos para ingresar el PIN y cambiar la contraseña
                            ObjCorreo.txtPin.Enabled = true;
                            ObjCorreo.txtUsuario.Enabled = true;
                            ObjCorreo.txtContraseñaNueva.Enabled = true;
                            ObjCorreo.txtContraseñaConfirmada.Enabled = true;
                            ObjCorreo.btnCambiarContra.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("No se pudo enviar el correo. Error: " + response.StatusCode.ToString(), "Sistema de gestión de cafetines", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocurrió un error al enviar el correo: {ex.Message}");
                    }
                }
                else
                {
                    MessageBox.Show("El correo ingresado no existe. Verifique los datos e intente nuevamente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor, ingrese su correo electrónico.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void CambiarClave(object sender, EventArgs e)
        {
            if (!(string.IsNullOrEmpty(ObjCorreo.txtPin.Text.Trim()) ||
                  string.IsNullOrEmpty(ObjCorreo.txtUsuario.Text.Trim()) ||
                  string.IsNullOrEmpty(ObjCorreo.txtContraseñaNueva.Text.Trim()) ||
                  string.IsNullOrEmpty(ObjCorreo.txtContraseñaConfirmada.Text.Trim())))
            {
                if (VerificarPIN() && VerificarUsuario())
                {
                    if (RestablecerClave())
                    {
                        MessageBox.Show("Contraseña restablecida con éxito. Ya puedes iniciar sesión.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ObjCorreo.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("La contraseña no pudo ser actualizada. Inténtalo de nuevo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("El PIN o el usuario son incorrectos. Verifica la información.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor, completa todos los campos para restablecer la contraseña.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        bool VerificarPIN()
        {
            return ObjCorreo.txtPin.Text.Trim() == codigoAleatorio;
        }

        bool VerificarUsuario()
        {
            return ObjCorreo.txtUsuario.Text.Trim() == usuario;
        }

        bool RestablecerClave()
        {
            DAOCambiarContra daoVerificar = new DAOCambiarContra();
            ClasesComunes commonClasses = new ClasesComunes();

            // Verificar que ambas contraseñas coincidan
            if (ObjCorreo.txtContraseñaNueva.Text.Trim().Equals(ObjCorreo.txtContraseñaConfirmada.Text.Trim()))
            {
                // Verificar que la contraseña cumple con el formato requerido
                if (commonClasses.EsValida(ObjCorreo.txtContraseñaConfirmada.Text.Trim()))
                {
                    // Hashear la contraseña antes de enviarla al DAO
                    daoVerificar.Password = commonClasses.ComputeSha256Hash(ObjCorreo.txtContraseñaConfirmada.Text.Trim());
                    daoVerificar.User = ObjCorreo.txtUsuario.Text.Trim();  // Asegurarse de que el usuario es el correcto

                    // Llamar al método que cambia la contraseña en la base de datos
                    if (daoVerificar.DAOCambiarclave())
                    {
                        // Si devuelve true, la contraseña se cambió exitosamente
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar la contraseña. Verifica que el usuario exista.");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Recuerda utilizar el formato correcto para la contraseña.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Las contraseñas no coinciden.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private string GenerateRandomCode(int length)
        {
            Random random = new Random();
            const string chars = "0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }

}

