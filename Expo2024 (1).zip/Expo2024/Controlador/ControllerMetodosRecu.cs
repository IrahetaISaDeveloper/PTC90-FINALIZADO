﻿using Expo2024.Vista.Recuperacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Controlador
{
    internal class ControllerMetodosRecu
    {
        ViewMetodosRecuperacion vista;

        public ControllerMetodosRecu(ViewMetodosRecuperacion vista)
        {
            this.vista = vista;
            vista.btnIntervencion.Click += new EventHandler(AbrirIntervencionAdmin);
            vista.btnPreguntas.Click += new EventHandler(AbrirPreguntas);
            vista.btnCorreo.Click += new EventHandler(AbrirCorreo);
        }

        void AbrirIntervencionAdmin(object sender, EventArgs e)
        {
            ViewIntervencionAdmin openForm = new ViewIntervencionAdmin();
            openForm.ShowDialog();
        }

        void AbrirPreguntas(object sender, EventArgs e)
        {
            ViewPreguntasRecuperacion openForm = new ViewPreguntasRecuperacion();
            openForm.ShowDialog();
        }

        void AbrirCorreo(object sender, EventArgs e)
        {
            ViewRecuperacionCorreo openForm = new ViewRecuperacionCorreo();
            vista.Hide();
            openForm.ShowDialog();
        }
    }
}
