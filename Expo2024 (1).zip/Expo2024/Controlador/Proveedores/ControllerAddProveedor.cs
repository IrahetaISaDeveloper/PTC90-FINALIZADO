﻿using Expo2024.Modelo.DAO.Proveedores;
using Expo2024.Vista.Proveedores;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador.Proveedores
{
    internal class ControllerAddProveedor
    {
        ViewAddProveedores vista;
        ViewAdminProveedores vista2Form = new ViewAdminProveedores();
        Control objcontrol;


        public ControllerAddProveedor(ViewAddProveedores vista)
        {
            this.vista = vista;
            vista.Load += new EventHandler(CargaInicial);
            vista.BtnAgregar.Click += new EventHandler(AgregarProveedor);
            vista.txtTelefono.KeyPress += new KeyPressEventHandler(ValidacionNumeros);
            vista.txtNombre.KeyPress += new KeyPressEventHandler(ValidacionLetras);
        }

        void ValidacionLetras(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("No se pueden agregar números en el nombre de un proveedor.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Handled = true;
                return;
            }
            else
            {
                vista.txtNombre.MaxLength = 50;

            }
        }

        void ValidacionNumeros(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("No se pueden agregar letras en un número telefónico.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Handled = true;
                return;
            }
            else
            {
                vista.txtTelefono.MaxLength = 8;
            }
        }

        void CargaInicial(object sender, EventArgs e)
        {
            LlenarComboCategoProveAgregar();
        }

        void LlenarComboCategoProveAgregar()
        {
            DAOProveedores daoProCo = new DAOProveedores();
            DataSet ds = daoProCo.ObtenerCategoria();
            vista.cmbCategoria.DataSource = ds.Tables["categoria"];
            vista.cmbCategoria.DisplayMember = "nombre";
            vista.cmbCategoria.ValueMember = "id_Categoria";
        }

        void AgregarProveedor(object sender, EventArgs e)
        {

            bool ValidarCorreo()
            {
                string email = vista.txtCorreo.Text.Trim();
                if (!(email.Contains("@")))
                {
                    MessageBox.Show("Formato de correo invalido, verifica que contiene @.", "Formato incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                // Validación del dominio (ejemplo simplificado)
                string[] dominiosPermitidos = { "gmail.com", "ricaldone.edu.sv" };
                string extension = email.Substring(email.LastIndexOf('@') + 1);
                if (!dominiosPermitidos.Contains(extension))
                {
                    MessageBox.Show("Dominio del correo es invalido, el sistema unicamente admite dominios 'gmail.com' y 'correo institucional'.", "Formato incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                return true;
            }

            DAOProveedores daoAgregar = new DAOProveedores();

            string nombre = vista.txtNombre.Text.Trim();
            string direccion = vista.txtDireccion.Text.Trim();
            string correo = vista.txtCorreo.Text.Trim();
            string telefono = vista.txtTelefono.Text.Trim();

            bool accion = ValidarCorreo();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(direccion)
                || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(telefono))
            {
                MessageBox.Show("Los campos no pueden estar vacios", "Error de validacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (nombre.Length > 50)
            {
                MessageBox.Show("El nombre no puede exeder los 50 caracteres");
                return;

            }

            else if (accion == true)
            {

                try
                {
                    DAOProveedores daoInsert = new DAOProveedores
                    {
                        Nombre = vista.txtNombre.Text.Trim(),
                        Direccion = vista.txtDireccion.Text.Trim(),
                        Telefono = vista.txtTelefono.Text.Trim(),
                        Correo = vista.txtCorreo.Text.Trim(),
                        Id_Categoria = (int)vista.cmbCategoria.SelectedValue
                    };

                    int valor = daoInsert.registarProveedor();

                    if (valor > 0)
                    {
                        MessageBox.Show("Proveedor guardado exitosamente");
                        LlenarDataGridView();

                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar el proveedor");
                    }

                    vista.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }

        }

        public void RefrescarTabla(object sender, EventArgs e)
        {
            LlenarDataGridView();
        }

        public void LlenarDataGridView()
        {
            DAOProveedores daoProve = new DAOProveedores();
            DataSet ds = daoProve.obtenerProveedores();
            vista2Form.dgvProvee.DataSource = ds.Tables["proveedor"];
        }
    }
}
