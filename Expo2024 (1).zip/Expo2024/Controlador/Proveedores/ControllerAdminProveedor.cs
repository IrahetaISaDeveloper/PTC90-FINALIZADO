﻿using Expo2024.Modelo.DAO.Proveedores;
using Expo2024.Vista.Proveedores;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador.Proveedores
{
    internal class ControllerAdminProveedor
    {
        ViewAddProveedores vistaAdd;
        ViewAdminProveedores objvista;
        ViewActualizarProveedores acVista = new ViewActualizarProveedores();


        public ControllerAdminProveedor(ViewAdminProveedores objvista)
        {
            this.objvista = objvista;
            objvista.Load += new EventHandler(CargaInicial);
            objvista.cmsEliminar.Click += new EventHandler(EliminarProv);
            objvista.cmsActualizar.Click += new EventHandler(AbrirActualizarProv);
            objvista.btnResrescar.Click += new EventHandler(RefrescarTabla);
            objvista.BtnAgregar1.Click += new EventHandler(CargarFormulario);
            objvista.btnBuscarProv.Click += new EventHandler(BuscarProveedoresEvento);

        }

        void CargarFormulario(object sender, EventArgs e)
        {
            ViewAddProveedores viewAddProveedores = new ViewAddProveedores();
            viewAddProveedores.ShowDialog();
            LlenarDataGridViewProvee();
        }

        void CargaInicial(object sender, EventArgs e)
        {
            LlenarDataGridViewProvee();
        }
        public void RefrescarTabla(object sender, EventArgs e)
        {
            LlenarDataGridViewProvee();
        }



        public void BuscarProveedoresEvento(object sender, EventArgs e)
        {
            DAOProveedores objbuscar = new DAOProveedores();
            DataSet ds = objbuscar.buscarPersonas(objvista.txtBuscarProve.Text.Trim());
            objvista.dgvProvee.DataSource = ds.Tables["proveedor"];
        }

        void AbrirActualizarProv(object sender, EventArgs e)
        {
            ViewActualizarProveedores form = new ViewActualizarProveedores();


            //Capturando los valores de la fila seleccionada
            string proveedorId = objvista.dgvProvee.CurrentRow.Cells["id_Proveedor"].Value.ToString();
            string nombreProveedor = objvista.dgvProvee.CurrentRow.Cells["nombre"].Value.ToString();
            string direccion = objvista.dgvProvee.CurrentRow.Cells["direccion"].Value.ToString();
            string telefono = objvista.dgvProvee.CurrentRow.Cells["telefono"].Value.ToString();
            string correo = objvista.dgvProvee.CurrentRow.Cells["correo"].Value.ToString();
            string Categoria = objvista.dgvProvee.CurrentRow.Cells["Articulos que provee"].Value.ToString();

            //Se envía a cada control de la vista el valor de cada columna del dataGridView
            form.txtIDActualizar.Text = proveedorId;
            form.txtNombreActualizar.Text = nombreProveedor;
            form.txtDireccionActualizar.Text = direccion;
            form.txtTelefonoActualizar.Text = telefono;
            form.txtCorreoActualizar.Text = correo;
            form.cmbCategoriaActualizar.SelectedText = Categoria;

            form.ShowDialog();
            LlenarDataGridViewProvee();

        }

        void EliminarProv(object sender, EventArgs e)
        {
            DAOProveedores daoDelete = new DAOProveedores();
            daoDelete.Id_Proveedor = (int)objvista.dgvProvee.SelectedCells[0].Value;
            int retorno = daoDelete.EliminarProv();
            if (retorno == 1)
            {
                MessageBox.Show("El proveedor seleccionado fue eliminado", "Proceso completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("El proveedor seleccionado no pudo ser eliminado", "Proceso incompleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            LlenarDataGridViewProvee();
        }

        public void LlenarDataGridViewProvee()
        {
            DAOProveedores daoProve = new DAOProveedores();
            DataSet ds = daoProve.obtenerProveedores();
            objvista.dgvProvee.DataSource = ds.Tables["ViewProvider"];
        }
    }
}
