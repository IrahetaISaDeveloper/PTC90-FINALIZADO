﻿using Expo2024.Modelo.DAO.Proveedores;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Vista.Proveedores;

namespace Expo2024.Controlador.Proveedores
{
    internal class ControllerActualizarProveedor
    {
        ViewActualizarProveedores objvista;


        public ControllerActualizarProveedor(ViewActualizarProveedores objvista)
        {
            this.objvista = objvista;
            objvista.Load += new EventHandler(CargaInicial);
            objvista.btnActualizarDef.Click += new EventHandler(ActualizarProvDef);
            objvista.txtTelefonoActualizar.KeyPress += new KeyPressEventHandler(ValidacionNumeros);
            objvista.txtNombreActualizar.KeyPress += new KeyPressEventHandler(ValidacionLetras);
        }

        void CargaInicial(object sender, EventArgs e)
        {
            LlenarComboActualizar();
        }

        void ValidacionLetras(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("No se puden agregar numeros o caracteres en el nombre de un proveedor.");
                e.Handled = true;
                return;
            }
            else
            {
                objvista.txtNombreActualizar.MaxLength = 50;
            }
        }

        void ValidacionNumeros(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("No se puden agregar letras en un numero telefonico");
                e.Handled = true;
                return;
            }
            else
            {
                objvista.txtTelefonoActualizar.MaxLength = 8;
            }
        }

        void LlenarComboActualizar()
        {
            DAOProveedores daoProCo = new DAOProveedores();
            DataSet ds = daoProCo.ObtenerCategoria();
            objvista.cmbCategoriaActualizar.DataSource = ds.Tables["categoria"];
            objvista.cmbCategoriaActualizar.DisplayMember = "nombre";
            objvista.cmbCategoriaActualizar.ValueMember = "id_Categoria";
        }
        public void ActualizarProvDef(object sender, EventArgs e)
        {
            DAOProveedores daoProvee = new DAOProveedores();


            daoProvee.Nombre = objvista.txtNombreActualizar.Text.Trim();
            daoProvee.Direccion = objvista.txtDireccionActualizar.Text.Trim();
            daoProvee.Telefono = objvista.txtTelefonoActualizar.Text.Trim();
            daoProvee.Correo = objvista.txtCorreoActualizar.Text.Trim();
            daoProvee.Id_Categoria = (int)objvista.cmbCategoriaActualizar.SelectedValue;
            daoProvee.Id_Proveedor = int.Parse(objvista.txtIDActualizar.Text.Trim());

            string nombre = objvista.txtNombreActualizar.Text.Trim();
            string direecion = objvista.txtDireccionActualizar.Text.Trim();
            string telefono = objvista.txtTelefonoActualizar.Text.Trim();
            string correo = objvista.txtCorreoActualizar.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(direecion)
               || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(telefono))
            {
                MessageBox.Show("Los campos no pueden estar vacios", "Error de validacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (nombre.Length > 50)
            {
                MessageBox.Show("El nombre no puede exeder los 50 caracteres");
                return;

            }
            else
            {
                int retorno = daoProvee.ActualizarProve();
                if (retorno == 1)
                {
                    MessageBox.Show("El proveedor se actualizo Correctamente");
                    objvista.Close();
                }
                else
                {
                    MessageBox.Show("El proveedor seleccionado no pudo ser actualizado");
                    MessageBoxIcon icon = MessageBoxIcon.Error;
                }
            }
        }
    }
}
