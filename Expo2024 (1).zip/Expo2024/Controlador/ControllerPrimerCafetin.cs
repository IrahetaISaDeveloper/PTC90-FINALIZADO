﻿using Expo2024.Modelo.DAO;
using Expo2024.Vista.Primer_Uso;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerPrimerCafetin
    {
        ViewPrimerCafetin view;
        bool accion;

        public ControllerPrimerCafetin(ViewPrimerCafetin Vista)
        {
            view = Vista;
            Vista.btnGuardar.Click += new EventHandler(GuardarInfo);
        }

        void GuardarInfo(object sender, EventArgs e)
        {
            try
            {
                if (!(string.IsNullOrEmpty(view.txtNombreCafetin.Text.Trim()) ||
                   string.IsNullOrEmpty(view.txtCorreo.Text.Trim()) ||
                   string.IsNullOrEmpty(view.txtDireccion.Text.Trim()) ||
                   string.IsNullOrEmpty(view.txtTelefono.Text.Trim())))
                {
                    DAOPrimerUso DAOGuardar = new DAOPrimerUso();
                    DAOGuardar.NameCafetin = view.txtNombreCafetin.Text.Trim();
                    DAOGuardar.CorreoCafetin = view.txtCorreo.Text.Trim();
                    DAOGuardar.TelefonoCafetin = view.txtTelefono.Text.Trim();
                    DAOGuardar.FechaCreacion = view.dtpFecha.Value.Date;
                    DAOGuardar.Direccion = view.txtDireccion.Text.Trim();
                    


                    accion = ValidarCorreo();
                    if (accion == true)
                    {
                        bool respuesta = DAOGuardar.RegistrarNegocio();
                        if (respuesta != false)
                        {
                            MessageBox.Show($"Tu Cafetin ha sido registrado exitosamente.", "Paso 1 completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ViewPrimerCafetin nextForm = new ViewPrimerCafetin();
                            nextForm.Show();
                            view.Dispose();
                        }
                        else
                        {
                            MessageBox.Show($"Algo salio mal, Revisa que los datos sean correctos.", "Paso 1 interrumpido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show($"Todos los campos son requeridos.", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Error al procesar información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        bool ValidarCorreo()
        {
            string email = view.txtCorreo.Text.Trim();
            if (!(email.Contains("@")))
            {
                MessageBox.Show("Formato de correo invalido, verifica que contiene @.", "Formato incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Validación del dominio (ejemplo simplificado)
            string[] dominiosPermitidos = { "gmail.com", "ricaldone.edu.sv" };
            string extension = email.Substring(email.LastIndexOf('@') + 1);
            if (!dominiosPermitidos.Contains(extension))
            {
                MessageBox.Show("Dominio del correo es invalido, el sistema unicamente admite dominios 'gmail.com' y 'correo institucional'.", "Formato incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
    }
}
