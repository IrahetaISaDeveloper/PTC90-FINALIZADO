﻿using Expo2024.Vista.Recuperacion;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerCambiarContrasenaPU
    {
        ViewIntervencionAdmin CambiarContra;

        public ControllerCambiarContrasenaPU(ViewIntervencionAdmin vista)
        {
            CambiarContra = vista;
            //CambiarContra.btnVerificar.Click += new EventHandler(SaveNewPassword);
        }

        //public void SaveNewPassword(object sender, EventArgs e)
        //{
        //    SqlCommand sqlCommand = new SqlCommand();

        //     DAOdatacambiarClave = new DAOCambiarClave();
        //    CommonClassesController commonClasses = new CommonClassesController();
        //    DAOdatacambiarClave.LoginName1 = objNewPassword.txtNameUserAdmin.Text;
        //    DAOdatacambiarClave.Password1 = objNewPassword.txtNuevaContraseñaNuevaAdmin.Text;
        //    string cadenaencriptada = commonClasses.ComputeSha256Hash(objNewPassword.txtNuevaContraseñaNuevaAdmin.Text);
        //    string cadenaencriptada2 = commonClasses.ComputeSha256Hash(objNewPassword.txtConfirmarContraseñaNuevaAdmin.Text);

        //    DAOdatacambiarClave.Password1 = commonClasses.ComputeSha256Hash(objNewPassword.txtConfirmarContraseñaNuevaAdmin.Text);

        //    if (!(string.IsNullOrEmpty(objNewPassword.txtNameUserAdmin.Text.Trim()) ||
        // string.IsNullOrEmpty(objNewPassword.txtConfirmarContraseñaNuevaAdmin.Text.Trim()) || string.IsNullOrEmpty(objNewPassword.txtNuevaContraseñaNuevaAdmin.Text.Trim())))
        //    {

        //        bool respuesta = DAOdatacambiarClave.ComprobarusuarioPorAdmin();
        //        if (cadenaencriptada == cadenaencriptada2 && respuesta == true)
        //        {
        //            DAOdatacambiarClave.DAOCambiarclave();
        //            MessageBox.Show("La contraseña se ha cambiado correctamente", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            objNewPassword.Hide();


        //            FrmLogin frmLogin = new FrmLogin();
        //            frmLogin.Show();


        //        }
        //        else
        //        {
        //            MessageBox.Show("Revise si  la contraseña nueva y confirmar contraseña coinciden o si el usuario ingresado es correcto ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Ingrese una nueva contraseña", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //    }

        //}
    }
}
