﻿using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DAO;
using Expo2024.Vista.Recuperacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Vista;
using Expo2024.Modelo;
using System.Data.SqlClient;

namespace Expo2024.Controlador.Login
{
    internal class ControllerLogin
    {
        ViewLogin ObjLogin;

        void ModosDeRecuperarContraseñas(object sender, EventArgs e)
        {
            ViewMetodosRecuperacion AbrirFromularios = new ViewMetodosRecuperacion();
            AbrirFromularios.Show();
            ObjLogin.Hide();
        }

        public ControllerLogin(ViewLogin Vista)
        {
            ObjLogin = Vista;
            ObjLogin.btnAcceder.Click += new EventHandler(AccesoAlosDatos);

            ObjLogin.txtUsuario.Enter += new EventHandler(IngresarUsuario);
            ObjLogin.txtUsuario.Leave += new EventHandler(dejarUsuario);

            ObjLogin.linkRecuContrasena.Click += new EventHandler(ModosDeRecuperarContraseñas);

            ObjLogin.btnProbarCone.Click += new EventHandler(ComprobarConexion);
            ObjLogin.Mostrar.Click += new EventHandler(MostrarContra);
            ObjLogin.Ocultar.Click += new EventHandler(OcultarContra);

            ObjLogin.txtContrasena.Enter += new EventHandler(IngresarContra);
            ObjLogin.txtContrasena.Leave += new EventHandler(DejarContra);

            ObjLogin.btnCerrar.Click += new EventHandler(QuitarVentana);
        }

       

        private void AccesoAlosDatos(object sender, EventArgs e)
        {
            DAOLogin DAOData = new DAOLogin();
            ClasesComunes common = new ClasesComunes();

            string username = ObjLogin.txtUsuario.Text.Trim();
            string password = ObjLogin.txtContrasena.Text.Trim();

            // Hash the input password
            string hashedPassword = common.ComputeSha256Hash(password);

            // Check if the username and password are valid
            if (DAOData.Login(username, hashedPassword))
            {
                // Login successful
                ObjLogin.Hide();
                ViewInicio viewDashboard = new ViewInicio();
                viewDashboard.Show();
            }
            else
            {
                MessageBox.Show("Datos incorrectos", "Error al iniciar sesión", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void MostrarContra(object sender, EventArgs e)
        {
            ObjLogin.txtContrasena.UseSystemPasswordChar = false;
            ObjLogin.Mostrar.Visible = false;
            ObjLogin.Ocultar.Visible = true;
        }

        private void OcultarContra(object sender, EventArgs e)
        {
            ObjLogin.txtContrasena.UseSystemPasswordChar = true;
            ObjLogin.Mostrar.Visible = true;
            ObjLogin.Ocultar.Visible = false;
        }

        private void IngresarUsuario(object sender, EventArgs e)
            {
                if (ObjLogin.txtContrasena.Text.Length < 100 || ObjLogin.txtUsuario.Text.Length < 100)
                {
                    if (ObjLogin.txtUsuario.Text.Trim().Equals("Usuario"))
                    {
                        ObjLogin.txtUsuario.Clear();
                        ObjLogin.txtUsuario.Visible = true;
                    }
                }
                else
                {
                    MessageBox.Show("Pasastes el maximo de caracteristicas", "Error de capacidad", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }



            private void dejarUsuario(object sender, EventArgs e)
            {

                if (ObjLogin.txtUsuario.Text.Trim().Equals(""))
                {
                    ObjLogin.txtUsuario.Text = "Usuario";
                }
            }



            /// <summary>
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            ///

            private void IngresarContra(object sender, EventArgs e)
            {
                if (ObjLogin.txtContrasena.Text.Trim().Equals("Contraseña"))
                {
                    ObjLogin.txtContrasena.Clear();
                    ObjLogin.txtContrasena.UseSystemPasswordChar = true;
                }
            }


            /// <summary>
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void DejarContra(object sender, EventArgs e)
            {
                if (ObjLogin.txtContrasena.Text.Trim().Equals(""))
                {
                    ObjLogin.txtContrasena.Text = "Contraseña";
                    ObjLogin.txtContrasena.PasswordChar = '\0';
                }
            }

            private void ComprobarConexion(object sender, EventArgs e)
            {
                //Se hace referencia a la clase dbContext y su método getConnection y se evalúa
                // si el retorno es nulo o no, en caso de ser nulo se mostrará el primer mensaje
                //de lo contrario se mostrará el código del segmento else.
                if (dbContext.getConnection() == null)
                {
                    MessageBox.Show("No fue posible realizar la conexión al servidor y/o la base de datos.", "Conexión fallida", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {
                    MessageBox.Show("La conexión al servidor y la base de datos se ha ejecutado correctamente.", "Conexión exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }


            /// <summary>
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            ///

            private void QuitarVentana(object sender, EventArgs e)
            {
                Application.Exit();
            }
    }
}
