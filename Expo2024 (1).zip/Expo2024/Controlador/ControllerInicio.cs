﻿using Expo2024.Controlador.Helper;
using Expo2024.Controlador.Login;
using Expo2024.Modelo;
using Expo2024.Modelo.DTO;
using Expo2024.Vista;
using Expo2024.Vista.Empleados;
using Expo2024.Vista.Productos;
using Expo2024.Vista.Proveedores;
using Expo2024.Vista.Recuperacion;
using Expo2024.Vista.Ventas;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerInicio
    {
        //Objeto de la vista ViewLogin
        ViewInicio ObjDashboard;
        Form Form = null;

        public ControllerInicio(ViewInicio View)
        {
            //Se asigna al objeto ObjDashboard todo lo que proviene el objeto View del constructor
            ObjDashboard = View;
            //Se utiliza el evento Load, el cual se ejecuta de forma inmediata cuando el formulario se inicia.
            View.Load += new EventHandler(EventosIniciales);
            //Al componente lblUsername se le asigna el valor de variable de sesión
            ObjDashboard.lblUsuario2.Text = SessionVar.Usuario;
            
            //Se invoca al evento AbrirFormularioAdminUsuarios para que este puede ser mostrado segú el boton que el usuario presione.
            ObjDashboard.btnEmpleados.Click += new EventHandler(AbrirFormularioEmpleados);
            ObjDashboard.btnProductos.Click += new EventHandler(AbrirFormularioProductos);
            ObjDashboard.btnProveedores.Click += new EventHandler(AbrirFormularioProveedores);
            ObjDashboard.btnVentas.Click += new EventHandler(AbrirFormularioVentas);
            ObjDashboard.FormClosing += new FormClosingEventHandler(cerrarPrograma);
            ObjDashboard.btnCerrarSesion.Click += new EventHandler(Logout);
            ObjDashboard.btnPreguntas.Click += new EventHandler(AbrirFormularioPreguntas);
        }

        /// <summary>
        /// Los eventos iniciales son aquellos que se ejecutarán de forma inmediata cuando se invoque a formualrio.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void EventosIniciales(object sender, EventArgs e)
        {
            Acceso();
        }

        /// <summary>
        /// El metodo acceso determina que accesos tendrá disponibles el usuario cuando inicie sesión.
        /// </summary>
        public void Acceso()
        {
            //Estructura selectiva para evaluar los posibles valores de la vraible Access
            switch (SessionVar.Acceso)
            {
                case "Administrador":
                    break;
                case "Bodeguero":
                    ObjDashboard.btnEmpleados.Visible = false;
                    ObjDashboard.btnInformes.Visible = false;
                    ObjDashboard.btnVentas.Visible = false;
                    ObjDashboard.btnProveedores.Visible = false;
                    break;
                case "Vendedor":
                    ObjDashboard.btnEmpleados.Visible = false;
                    ObjDashboard.btnInformes.Visible = false;
                    ObjDashboard.btnProductos.Visible = false;
                    ObjDashboard.btnProveedores.Visible = false;
                    break;
                default:
                    break;
            }
        }

        

        private void AbrirFormularioEmpleados(object sender, EventArgs e)
        {
            ViewAdminEmpleados abrir = new ViewAdminEmpleados();
            abrir.Show();
            
        }

        private void AbrirFormularioProductos(object sender, EventArgs e)
        {
            ViewAdminProducto abrir = new ViewAdminProducto();
            abrir.Show();
        }

        private void AbrirFormularioVentas(object sender, EventArgs e)
        {
            ViewAdminVentas abrir = new ViewAdminVentas();
            abrir.Show();
        }

        private void AbrirFormularioProveedores(object sender, EventArgs e)
        {
            ViewAdminProveedores abrir = new ViewAdminProveedores();
            abrir.Show();
        }

        private void AbrirFormularioPreguntas(object sender, EventArgs e)
        {
            ViewCreacionPreguntas abrir = new ViewCreacionPreguntas();
            abrir.Show();
        }


        /// <summary>
        /// Método para abrir formularios dentro del panel contenedor del formulario principal
        /// </summary>
        /// <typeparam name="MiForm"></typeparam>
        //private void AbrirFormulario<MiForm>() where MiForm : Form, new()
        //{
        //    //Se declara objeto de tipo Form llamada formulario
        //    Form formulario;
        //    //Se guarda en el panel contenedor del formulario principal todos los controles del formulario que desea abrir <MiForm> posteriormente se guarda todo en el objeto de tipo formulario
        //    formulario = ObjDashboard.panelNavegacion.Controls.OfType<MiForm>().FirstOrDefault();
        //    //Si el formulario no existe se procederá a crearlo de lo contrario solo se traerá al frente (ver clausula else)
        //    if (formulario == null)
        //    {
        //        //Se define un nuevo formulario para guardarse como nuevo objeto MiForm
        //        formulario = new MiForm();
        //        //Se especifica que el formulario debe mostrarse como ventana
        //        formulario.TopLevel = false;
        //        //Se eliminan los bordes del formulario
        //        formulario.FormBorderStyle = FormBorderStyle.None;
        //        //Se establece que se abrira en todo el espacio del formulario padre
        //        formulario.Dock = DockStyle.Fill;
        //        //Se le asigna una opacidad de 0.75
        //        formulario.Opacity = 0.75;
        //        //Se evalua el formulario actual para verificar si es nulo
        //        if (Form != null)
        //        {
        //            //Se cierra el formulario actual para mostrar el nuevo formulario
        //            Form.Close();
        //            //Se eliminan del panel contenedor todos los controles del formulario que se cerrará
        //            ObjDashboard.panelNavegacion.Controls.Remove(Form);
        //        }
        //        //Se establece como nuevo formulario actual el formulario que se está abriendo
        //        Form = formulario;
        //        //Se agregan los controles del nuevo formulario al panel contenedor
        //        ObjDashboard.panelNavegacion.Controls.Add(formulario);
        //        //Tag es una propiedad genérica disponible para la mayoría de los controles en aplicaciones .NET, incluyendo los paneles.
        //        ObjDashboard.panelNavegacion.Tag = formulario;
        //        //Se muestra el formulario en el panel contenedor
        //        formulario.Show();
        //        //Se trae al frente el formulario armado
        //        formulario.BringToFront();
        //    }
        //    else
        //    {
        //        formulario.BringToFront();
        //    }
        //}

        private void CerrarForm(object sender, EventArgs e)
        {
            if (Form != null)
            {
                //Se cierra el formulario actual para mostrar el nuevo formulario
                Form.Close();
                //Se eliminan del panel contenedor todos los controles del formulario que se cerrará
                ObjDashboard.panelNavegacion.Controls.Remove(Form);
            }
        }

        private void cerrarPrograma(Object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("¿Estas seguro que quieres salir?, se cerrara la sesion actual", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void Logout(Object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea cerrar sesión?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                LimpiarVariablesSesion();
                ViewLogin backForm = new ViewLogin();
                backForm.Show();
                ObjDashboard.Dispose();
            }
        }

        void LimpiarVariablesSesion()
        {
            SessionVar.Usuario = string.Empty;
            SessionVar.Contrasena = string.Empty;
            SessionVar.Nombre = string.Empty;
            SessionVar.Acceso = string.Empty;
            SessionVar.TipoUsuario = 0;
        }

        

        
    }
}
