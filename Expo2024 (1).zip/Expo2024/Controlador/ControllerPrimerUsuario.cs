﻿using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DAO;
using Expo2024.Modelo.DAO.Empleados;
using Expo2024.Vista;
using Expo2024.Vista.Primer_Uso;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerPrimerUsuario
    {
        ViewPrimerUsuario ObjView;

        public ControllerPrimerUsuario(ViewPrimerUsuario View)
        {
            ObjView = View;
            View.Load += new EventHandler(CargarCombos);
            View.btnCrearPrimer.Click += new EventHandler(CrearPrimerUsuario);
        }

        void CargarCombos(object sender, EventArgs e)
        {
            DAOEmpleados ObjAdmin = new DAOEmpleados();

            DataSet ds = ObjAdmin.ObtenerTiposEmpleado();
            ObjView.cmbTipoEmpleado.DataSource = ds.Tables["tipoEmpleado"];
            ObjView.cmbTipoEmpleado.ValueMember = "idTipo_Empleado";
            ObjView.cmbTipoEmpleado.DisplayMember = "nombreTipo_Empleado";

            DataSet data = ObjAdmin.ObtenerEstados();
            ObjView.cmbEstado.DataSource = data.Tables["estados"];
            ObjView.cmbEstado.ValueMember = "id_Estado";
            ObjView.cmbEstado.DisplayMember = "estado";

            DataSet datas = ObjAdmin.ObtenerTipoUsuario();
            ObjView.cmbTipoUsuario.DataSource = datas.Tables["tipoUsuario"];
            ObjView.cmbTipoUsuario.ValueMember = "idTipo_Usuario";
            ObjView.cmbTipoUsuario.DisplayMember = "nombreTipo_Usuario";
        }

        void CrearPrimerUsuario(object sender, EventArgs e)
        {
            DAOPU DAOAdmin = new DAOPU(); // Objeto que se usará para las operaciones de DB
            ClasesComunes common = new ClasesComunes();

            // Asignación de valores del formulario a DAOAdmin (Empleado y Usuario)
            DAOAdmin.Nombre = ObjView.txtNombre.Text.Trim();
            DAOAdmin.Apellido = ObjView.txtApellido.Text.Trim();
            DAOAdmin.Direccion = ObjView.txtDireccion.Text.Trim();
            DAOAdmin.Telefono = ObjView.txtTelefono.Text.Trim();
            DAOAdmin.Documento = ObjView.txtDocumento.Text.Trim();
            DAOAdmin.FechaNacimiento = ObjView.dtpNacimiento.Value.Date;
            DAOAdmin.Usuario = ObjView.txtUsuarioPrimer.Text.Trim(); // Nombre de usuario
            DAOAdmin.Correo = ObjView.txtCorreo.Text.Trim();
            DAOAdmin.IdTipoUsuario = (int)ObjView.cmbTipoUsuario.SelectedValue; // Tipo de usuario
            DAOAdmin.IdTipoEmpleado = (int)ObjView.cmbTipoEmpleado.SelectedValue; // Tipo de empleado
            DAOAdmin.IdEstado = (int)ObjView.cmbEstado.SelectedValue; // Estado del empleado

            // Llamada al método RegistrarNegocio() en DAOPU para realizar la inserción
            bool valorRetornado = DAOAdmin.RegistrarNegocio();

            if (valorRetornado == true)
            {
                // Mensaje de éxito
                MessageBox.Show("Los datos han sido registrados exitosamente",
                 "Proceso completado",
                 MessageBoxButtons.OK,
                 MessageBoxIcon.Information);

                // Mostrar credenciales de acceso
                MessageBox.Show($"Usuario administrador: {ObjView.txtUsuarioPrimer.Text.Trim()}\nContraseña de usuario: {ObjView.txtUsuarioPrimer.Text.Trim()}FU123",
                                "Credenciales de acceso",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                // Redirigir a la vista de login
                ViewLogin logear = new ViewLogin();
                logear.Show();
            }
            else
            {
                // Mensaje de error en caso de falla en la inserción
                MessageBox.Show("Los datos no pudieron ser registrados",
                                "Proceso interrumpido",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }
    }
}
