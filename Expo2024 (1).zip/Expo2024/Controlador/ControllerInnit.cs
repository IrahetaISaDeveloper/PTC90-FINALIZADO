﻿using Expo2024.Controlador.Helper;
using Expo2024.Modelo.DAO;
using Expo2024.Vista;
using Expo2024.Vista.Primer_Uso;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expo2024.Controlador
{
    internal class ControllerInnit
    {
        public static void ValidarVista()
        {
            //Se crea dos objetos para tener acceso al DAOLogin y DAOPrimerUsuario
            ClasesComunes objVal = new ClasesComunes();
            objVal.LeerArchivoXMLConexion();
            DAOLogin ObjLogin = new DAOLogin();
            DAOPrimerUso ObjUso = new DAOPrimerUso();
            int primerCafetin = ObjUso.VerificarRegistroCafetin();
            int PrimerUsuario = ObjLogin.ValidarPrimerUsoSistema();
            if (primerCafetin == 0)
            {
                Application.Run(new ViewPrimerCafetin());
            }
            else if (PrimerUsuario == 0)
            {
                Application.Run(new ViewPrimerUsuario());
            }
            else
            {
                Application.Run(new ViewLogin());
            }
        }
    }
}
