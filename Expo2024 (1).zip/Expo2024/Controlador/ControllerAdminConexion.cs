﻿using Expo2024.Modelo.DTO;
using Expo2024.Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Expo2024.Vista;

namespace Expo2024.Controlador
{
    internal class ControllerAdminConexion
    {
        ViewConexionAdmin ObjView;
        int origen;

        public ControllerAdminConexion(ViewConexionAdmin View, int origen)
        {
            ObjView = View;
            verificarOrigen(origen);
            ///tabcontrol 2
            View.rdDeshabilitarSeguridad.CheckedChanged += new EventHandler(rdSeleccionFalso);
            View.rdHabilitarSeguridad.CheckedChanged += new EventHandler(rdSeleccionVerdadero);
            View.btnGuardarInfo.Click += new EventHandler(GuardarRegistro);

        }

        public void verificarOrigen(int origen)
        {
            if (origen == 2)
            {
                //Cambiar configuración
                ObjView.txtServidor.Text = DTOdbContext.Server;
                ObjView.txtNombreBaseDatos.Text = DTOdbContext.Database;
                ObjView.txtSQLAuthentication.Text = DTOdbContext.User;
                ObjView.txtContrasenaSQL.Text = DTOdbContext.Password;
            }
        }

        #region Configuración del servidor
        void rdSeleccionFalso(object sender, EventArgs e)
        {
            if (ObjView.rdDeshabilitarSeguridad.Checked == true)
            {
                ObjView.pnlAuth.Enabled = true;
            }
        }

        void rdSeleccionVerdadero(object sender, EventArgs e)
        {
            if (ObjView.rdHabilitarSeguridad.Checked == true)
            {
                ObjView.pnlAuth.Enabled = false;
                ObjView.txtSQLAuthentication.Clear();
                ObjView.txtContrasenaSQL.Clear();
            }
        }

        void GuardarRegistro(object sender, EventArgs e)
        {
            GuardarConfiguracionXML();
        }
        public void GuardarConfiguracionXML()
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                //Crear declaración XML
                XmlDeclaration decl = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(decl);

                //Crear elemento raíz
                XmlElement root = doc.CreateElement("Conn");
                doc.AppendChild(root);

                //Crear los elementos hijos y agregarlos al elemento raíz
                XmlElement servidor = doc.CreateElement("Servidor");
                string servidorCode = CodificarBase64String(ObjView.txtServidor.Text.Trim());

                servidor.InnerText = servidorCode;
                root.AppendChild(servidor);

                XmlElement Database = doc.CreateElement("NombreDataBase");
                string DatabaseCode = CodificarBase64String(ObjView.txtNombreBaseDatos.Text.Trim());
                Database.InnerText = DatabaseCode;
                root.AppendChild(Database);

                if (ObjView.rdDeshabilitarSeguridad.Checked == true)
                {
                    XmlElement SqlAuth = doc.CreateElement("UsuarioAuthSQL");
                    string sqlAuthCode = CodificarBase64String(ObjView.txtSQLAuthentication.Text.Trim());
                    SqlAuth.InnerText = sqlAuthCode;
                    root.AppendChild(SqlAuth);

                    XmlElement SqlPass = doc.CreateElement("ContraseñaSQL");
                    string SqlPassCode = CodificarBase64String(ObjView.txtContrasenaSQL.Text.Trim());
                    SqlPass.InnerText = SqlPassCode;
                    root.AppendChild(SqlPass);
                }
                else
                {
                    XmlElement SqlAuth = doc.CreateElement("UsuarioSqlAuth");
                    SqlAuth.InnerText = string.Empty;
                    root.AppendChild(SqlAuth);

                    XmlElement SqlPass = doc.CreateElement("ContraseñaSql");
                    SqlPass.InnerText = string.Empty;
                    root.AppendChild(SqlPass);
                }
                SqlConnection con = dbContext.testConnection(ObjView.txtServidor.Text.Trim(), ObjView.txtNombreBaseDatos.Text.Trim(), ObjView.txtSQLAuthentication.Text.Trim(), ObjView.txtContrasenaSQL.Text.Trim());
                if (con != null)
                {
                    doc.Save("config_server.xml");
                    DTOdbContext.Server = ObjView.txtServidor.Text.Trim();
                    DTOdbContext.Database = ObjView.txtNombreBaseDatos.Text.Trim();
                    DTOdbContext.User = ObjView.txtSQLAuthentication.Text.Trim();
                    DTOdbContext.Password = ObjView.txtContrasenaSQL.Text.Trim();
                    MessageBox.Show($"El archivo fue creado exitosamente.", "Archivo de configuración", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ObjView.Dispose();
                }

            }
            catch (XmlException ex)
            {
                MessageBox.Show($"{ex.Message}, no se pudo crear el archivo de configuración.", "Consulte el manual técnico", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        #endregion

        public string CodificarBase64String(string textoacifrar)
        {
            try
            {
                byte[] bytes = Encoding.UTF8.GetBytes(textoacifrar);
                //Codificación base 64 string
                string base64String = Convert.ToBase64String(bytes);
                return base64String;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}
