﻿using Expo2024.Modelo.DAO.Ventas;
using Expo2024.Vista.Ventas;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Controlador.Ventas
{
    internal class ControllerAdminVentas
    {
        ViewAdminVentas VistaVentas;
        public ControllerAdminVentas(ViewAdminVentas vista) 
        {
            vista.btnAbrirVenta.Click += new EventHandler(AbrirFormulario);
        }

        private void RefrescarData()
        {
            DAOVentas dao = new DAOVentas();
            DataSet ventas = dao.ObtenerVentas();

            VistaVentas.dgvVentas.DataSource = ventas;
            VistaVentas.dgvVentas.Columns[0].Visible = false;

            VistaVentas.dgvVentas.Columns[1].HeaderText = "id_Venta";
            VistaVentas.dgvVentas.Columns[2].HeaderText = "fecha_Venta";
            VistaVentas.dgvVentas.Columns[3].HeaderText = "total_Venta";
         
        }

        void AbrirFormulario(object sender, EventArgs e)
        {
            ViewAddVentas abrir = new ViewAddVentas();
            abrir.ShowDialog();
        }
    }
}
