﻿using Expo2024.Vista.Ventas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Expo2024.Modelo.DAO.Ventas;
using System.Data;
using System.Windows.Forms;
using static Expo2024.Modelo.DTO.Ventas.DTOVentas;

namespace Expo2024.Controlador.Ventas
{
    internal class ControllerAddVentas
    {
       ViewAddVentas ObjVenta; // Referencia a la vista

        public ControllerAddVentas(ViewAddVentas vista)
        {
            this.ObjVenta = vista;
            this.ObjVenta.Load += new EventHandler(DatosIniciales);
            //vista.btnAgregarProducto.Click += new EventHandler(AgregarProducto);
            //vista.btnAgregarVenta.Click += new EventHandler(AgregarVenta);
        }

        public void DatosIniciales(object sender, EventArgs e)
        {
            RefrescarData();
        }

        private void RefrescarData()
        {
            DAOVentas dao = new DAOVentas();
            DataSet detalles = dao.ObtenerDetalles();

                ObjVenta.dgvDetalles.DataSource = detalles;
                //ObjVenta.dgvDetalles.Columns[0].Visible = false;

                ObjVenta.dgvDetalles.Columns[1].HeaderText = "Id_Producto";
                ObjVenta.dgvDetalles.Columns[2].HeaderText = "Cantidad";
                ObjVenta.dgvDetalles.Columns[3].HeaderText = "Descripcion";
                ObjVenta.dgvDetalles.Columns[4].HeaderText = "id_Venta";
                ObjVenta.dgvDetalles.Columns[5].HeaderText = "id_Empleado";
        }
        public class VentaController
        {
            private DAOVentas ventaDAO = new DAOVentas();

            public int CrearVenta(VentaDTO venta)
            {
                return ventaDAO.InsertVenta(venta);
            }

            public bool ActualizarVenta(VentaDTO venta)
            {
                return ventaDAO.UpdateVenta(venta);
            }

            public bool EliminarVenta(int idVenta)
            {
                return ventaDAO.DeleteVenta(idVenta);
            }
        }


    }
}
