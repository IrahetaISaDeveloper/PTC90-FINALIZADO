﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expo2024.Controlador.Helper
{
    internal class SessionVar
    {
        private static string usuario = string.Empty;
        private static string acceso = string.Empty;
        private static string nombre = string.Empty;
        private static string contrasena = string.Empty;
        private static int tipoUsuario = 0;

        public static string Usuario { get => usuario; set => usuario = value; }
        public static string Acceso { get => acceso; set => acceso = value; }
        public static string Nombre { get => nombre; set => nombre = value; }
        public static string Contrasena { get => contrasena; set => contrasena = value; }
        public static int TipoUsuario { get => tipoUsuario; set => tipoUsuario = value; }
    }
}
