﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Expo2024.Modelo.DAO;
using Expo2024.Vista;
using Expo2024.Vista.Recuperacion;

namespace Expo2024.Controlador
{
    internal class ControllerVerificacionDePreguntas
    {
        ViewPreguntasRecuperacion ObjPreguntas;
        int usuario;


        public ControllerVerificacionDePreguntas(ViewPreguntasRecuperacion vista)
        {
            ObjPreguntas = vista;
            ObjPreguntas.btnVerificar.Click += new EventHandler(Comparacion);
            ObjPreguntas.btnSalir.Click += new EventHandler(Salir);
        }

        public void Comparacion(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand();
            DAOPreguntas dao = new DAOPreguntas();
            dao.User = ObjPreguntas.txtUsuario.Text.Trim();
            dao.Pregunta1 = ObjPreguntas.txtRespuesta1.Text.Trim();
            dao.Pregunta2 = ObjPreguntas.txtRepuesta2.Text.Trim();
            dao.Pregunta3 = ObjPreguntas.txtRepuesta3.Text.Trim();
            

            bool respuesta = dao.ObtenerRespuestas();


            if (!(string.IsNullOrEmpty(ObjPreguntas.txtRespuesta1.Text.Trim()) ||
             string.IsNullOrEmpty(ObjPreguntas.txtRepuesta2.Text.Trim()) || 
             string.IsNullOrEmpty(ObjPreguntas.txtRepuesta3.Text.Trim())))
            {
                if (respuesta == true)
                {
                    MessageBox.Show("Las respuestas son correctas", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ObjPreguntas.Hide();
                    //ViewCambiarContra CambiarContra = new ViewCambiarContra(usuario);
                    //CambiarContra.Show();
                }
                else
                {
                    MessageBox.Show("Las respuestas son incorrectas, revise las respuestas que esta ingresando", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Necesita llenar los campos para cambiar su contraseña", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        void Salir(object sender, EventArgs e)
        {
            ViewMetodosRecuperacion abrir = new ViewMetodosRecuperacion();
            ObjPreguntas.Hide();
            abrir.Show();
        }

    }
}

